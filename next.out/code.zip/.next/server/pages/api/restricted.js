"use strict";
(() => {
var exports = {};
exports.id = 45;
exports.ids = [45,748];
exports.modules = {

/***/ 2756:
/***/ ((module) => {

module.exports = require("@trpc/server");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 5900:
/***/ ((module) => {

module.exports = require("pg");

/***/ }),

/***/ 2501:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _server_common_get_server_auth_session__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2399);

const restricted = async (req, res)=>{
    const session = await (0,_server_common_get_server_auth_session__WEBPACK_IMPORTED_MODULE_0__/* .getServerAuthSession */ .W)({
        req,
        res
    });
    if (session) {
        res.send({
            content: "This is protected content. You can access this content because you are signed in."
        });
    } else {
        res.send({
            error: "You must be signed in to view the protected content on this page."
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (restricted);


/***/ }),

/***/ 2399:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ getServerAuthSession)
/* harmony export */ });
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pages_api_auth_nextauth___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7720);


/**
 * Wrapper for unstable_getServerSession https://next-auth.js.org/configuration/nextjs
 * See example usage in trpc createContext or the restricted API route
 */ const getServerAuthSession = async (ctx)=>{
    return await (0,next_auth__WEBPACK_IMPORTED_MODULE_0__.unstable_getServerSession)(ctx.req, ctx.res, _pages_api_auth_nextauth___WEBPACK_IMPORTED_MODULE_1__.authOptions);
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [720], () => (__webpack_exec__(2501)));
module.exports = __webpack_exports__;

})();