"use strict";
exports.id = 790;
exports.ids = [790];
exports.modules = {

/***/ 6790:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VI": () => (/* binding */ useError),
/* harmony export */   "si": () => (/* binding */ useAuthType),
/* harmony export */   "wX": () => (/* binding */ useScreenerFilter)
/* harmony export */ });
/* harmony import */ var zustand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5671);
/* harmony import */ var zustand__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(zustand__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2166);


const intialScreener = {
    marketCap: {
        min: 0,
        max: Number.MAX_SAFE_INTEGER
    },
    avgVolume: {
        min: 0,
        max: Number.MAX_SAFE_INTEGER
    },
    PE: {
        min: _utils_constants__WEBPACK_IMPORTED_MODULE_1__/* .screenerConstants.PE.min */ .aq.PE.min,
        max: _utils_constants__WEBPACK_IMPORTED_MODULE_1__/* .screenerConstants.PE.max */ .aq.PE.max
    },
    DE: {
        min: _utils_constants__WEBPACK_IMPORTED_MODULE_1__/* .screenerConstants.DE.min */ .aq.DE.min,
        max: _utils_constants__WEBPACK_IMPORTED_MODULE_1__/* .screenerConstants.DE.max */ .aq.DE.max
    },
    beta: {
        min: _utils_constants__WEBPACK_IMPORTED_MODULE_1__/* .screenerConstants.beta.min */ .aq.beta.min,
        max: _utils_constants__WEBPACK_IMPORTED_MODULE_1__/* .screenerConstants.beta.max */ .aq.beta.max
    },
    price: {
        min: _utils_constants__WEBPACK_IMPORTED_MODULE_1__/* .screenerConstants.price.min */ .aq.price.min,
        max: _utils_constants__WEBPACK_IMPORTED_MODULE_1__/* .screenerConstants.price.max */ .aq.price.max
    }
};
const useScreenerFilter = zustand__WEBPACK_IMPORTED_MODULE_0___default()()((set)=>({
        value: intialScreener,
        setValue: (props)=>set((state)=>({
                    ...state,
                    value: props
                })),
        resetValue: ()=>set((state)=>({
                    ...state,
                    value: intialScreener
                }))
    }));
const useAuthType = zustand__WEBPACK_IMPORTED_MODULE_0___default()()((set)=>({
        authType: "signin",
        setAuthSignIn: ()=>set((state)=>({
                    authType: "signin"
                })),
        setAuthSignUp: ()=>set((state)=>({
                    authType: "signup"
                }))
    }));
const useError = zustand__WEBPACK_IMPORTED_MODULE_0___default()()((set)=>({
        errorAppear: false,
        message: "",
        setAppear: ()=>set((state)=>({
                    ...state,
                    errorAppear: true
                })),
        setDisappear: ()=>set((state)=>({
                    ...state,
                    errorAppear: false
                })),
        setMessage: (newMessage)=>set((state)=>({
                    ...state,
                    message: newMessage
                }))
    }));


/***/ }),

/***/ 2166:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Oc": () => (/* binding */ avgVolumeValues),
/* harmony export */   "Vy": () => (/* binding */ marketCapValues),
/* harmony export */   "aq": () => (/* binding */ screenerConstants)
/* harmony export */ });
/* unused harmony export today */
const screenerConstants = {
    marketCap: {
        min: 50 * 10 ** 6,
        max: 2 * 10 ** 12
    },
    avgVolume: {
        min: 50 * 10 ** 3,
        max: 5 * 10 ** 6
    },
    PE: {
        min: 0,
        max: 50
    },
    DE: {
        min: 0,
        max: 30
    },
    beta: {
        min: 0,
        max: 4
    },
    price: {
        min: 0,
        max: 200
    }
};
const marketCapValues = [
    0,
    5 * 10 ** 7,
    1.4 * 10 ** 8,
    4.2 * 10 ** 8,
    1.2 * 10 ** 9,
    3.5 * 10 ** 9,
    1 * 10 ** 10,
    2.9 * 10 ** 10,
    8.3 * 10 ** 10,
    2.4 * 10 ** 11,
    6.9 * 10 ** 11,
    2 * 10 ** 12,
    Number.MAX_SAFE_INTEGER
];
const avgVolumeValues = [
    0,
    5 * 10 ** 4,
    7.9 * 10 ** 4,
    1.3 * 10 ** 5,
    2 * 10 ** 5,
    3.2 * 10 ** 5,
    5 * 10 ** 5,
    7.9 * 10 ** 5,
    1.3 * 10 ** 6,
    2 * 10 ** 6,
    3.2 * 10 ** 6,
    5 * 10 ** 6,
    Number.MAX_SAFE_INTEGER
];
const today = new Date(new Date().toLocaleString("en-US", {
    timeZone: "America/New_York"
}));


/***/ })

};
;