exports.id = 805;
exports.ids = [805];
exports.modules = {

/***/ 6414:
/***/ ((module) => {

// Exports
module.exports = {
	"slider": "DiscreteSlider_slider__sH5a5",
	"sliderTrack": "DiscreteSlider_sliderTrack__X_SM7",
	"sliderRange": "DiscreteSlider_sliderRange__DoL0a",
	"thumb": "DiscreteSlider_thumb__XO6id",
	"thumbZ3": "DiscreteSlider_thumbZ3__PO3DD",
	"thumbZ4": "DiscreteSlider_thumbZ4__Y9_HT",
	"thumbZ5": "DiscreteSlider_thumbZ5__8pY7Y"
};


/***/ }),

/***/ 2081:
/***/ ((module) => {

// Exports
module.exports = {
	"slider": "MultiRangeSlider_slider__0Jb_p",
	"sliderTrack": "MultiRangeSlider_sliderTrack__G2Ekb",
	"sliderRange": "MultiRangeSlider_sliderRange__3zGVe",
	"thumb": "MultiRangeSlider_thumb__ReOvp",
	"thumbZ3": "MultiRangeSlider_thumbZ3__FzSid",
	"thumbZ4": "MultiRangeSlider_thumbZ4__0WYHp",
	"thumbZ5": "MultiRangeSlider_thumbZ5__koQwj"
};


/***/ }),

/***/ 2805:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Dm": () => (/* reexport */ Wrapper_Wrapper),
  "SB": () => (/* reexport */ CompanyProfile_CompanyProfile),
  "wn": () => (/* reexport */ Filter_Filter),
  "sQ": () => (/* reexport */ HeaderImage_HeaderImage),
  "CQ": () => (/* reexport */ HoldingsInformation_HoldingsInformation),
  "ak": () => (/* reexport */ MarketInfo_MarketInfo),
  "dN": () => (/* reexport */ MarketOverview_MarketOverview),
  "h7": () => (/* reexport */ MiniChart_MiniChart),
  "tc": () => (/* reexport */ PortfolioOverview_PortfolioOverview),
  "e_": () => (/* binding */ PortfolioPerformanceChart),
  "zc": () => (/* reexport */ PreviewOrder_PreviewOrder),
  "zi": () => (/* reexport */ SaveScreener_SaveScreener),
  "pw": () => (/* reexport */ SavedScreeners_SavedScreeners),
  "E1": () => (/* reexport */ SearchBar_SearchBar),
  "Uj": () => (/* reexport */ TickerChart_TickerChart),
  "Pe": () => (/* reexport */ TickerInfo_TickerInfo),
  "yp": () => (/* reexport */ TickerTechnicalAnalysis_TickerTechnicalAnalysis),
  "Dd": () => (/* reexport */ TradeOptions_TradeOptions),
  "cN": () => (/* reexport */ TrendingTickers_TrendingTickers),
  "TJ": () => (/* reexport */ Watchlist_Watchlist)
});

// UNUSED EXPORTS: Error, MarketPerformance, MultiRangeSlider, News, SideBar, TickerBanner

// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: external "react-icons/bi"
var bi_ = __webpack_require__(6652);
// EXTERNAL MODULE: external "react-icons/hi"
var hi_ = __webpack_require__(1111);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
// EXTERNAL MODULE: external "react-icons/tb"
var tb_ = __webpack_require__(4152);
// EXTERNAL MODULE: external "react-spinners"
var external_react_spinners_ = __webpack_require__(8176);
// EXTERNAL MODULE: ./src/utils/trpc.ts
var trpc = __webpack_require__(4097);
;// CONCATENATED MODULE: ./src/components/SideBar/SideBar.tsx










const buttonIconStyle = {
    height: "30px",
    width: "30px"
};
const avatarIconStyle = {
    height: "4rem",
    width: "4rem",
    color: "white"
};
const buttonStyle = "text-white text-left text-2xl h-14 pl-4 rounded-md flex flex-row items-center gap-6 hover:bg-green-600";
const chosenButtonStyle = "bg-beige-600 hover:bg-beige-600";
const SideBar = ()=>{
    const router = (0,router_.useRouter)();
    const { data: userData , isSuccess  } = trpc/* trpc.user.getUserInfo.useQuery */.S.user.getUserInfo.useQuery();
    const handleNavButtonClicked = (e)=>{
        const newDir = e.target.id;
        router.push("/" + newDir);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-green-700 w-sidebar h-screen max-h-screen fixed flex flex-col",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-100 my-10 mx-8 flex",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "text-white font-pacifico text-5xl",
                    children: "Stock Geek"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "ml-8 flex flex-row h-16 gap-2 items-center mb-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiUserCircle, {
                        style: avatarIconStyle
                    }),
                    isSuccess ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-white text-3xl",
                                children: userData.username
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                className: "text-slate-400 text-lg",
                                children: [
                                    "Current cash: $",
                                    new Intl.NumberFormat("en-US", {
                                        minimumFractionDigits: 2
                                    }).format(parseInt(userData.cash))
                                ]
                            })
                        ]
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_spinners_.ClipLoader, {
                            color: "#FFFFFF"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col mx-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-slate-400 text-2xl ml-4 uppercase",
                        children: "My Portal"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        id: "home",
                        className: `${buttonStyle} ${router.route.startsWith("/home") && chosenButtonStyle}`,
                        onClick: handleNavButtonClicked,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineHome, {
                                style: buttonIconStyle
                            }),
                            "Home"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        id: "portfolio",
                        className: `${buttonStyle} ${router.route.startsWith("/portfolio") && chosenButtonStyle}`,
                        onClick: handleNavButtonClicked,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(hi_.HiOutlinePresentationChartLine, {
                                style: buttonIconStyle
                            }),
                            "My Portfolio"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        id: "history",
                        className: `${buttonStyle} ${router.route.startsWith("/history") && chosenButtonStyle}`,
                        onClick: handleNavButtonClicked,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineHistory, {
                                style: buttonIconStyle
                            }),
                            "Trade History"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        id: "watchlist",
                        className: `${buttonStyle} ${router.route.startsWith("/watchlist") && chosenButtonStyle}`,
                        onClick: handleNavButtonClicked,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(tb_.TbNotebook, {
                                style: buttonIconStyle
                            }),
                            "Watchlist"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-slate-400 text-2xl ml-4 mt-2 uppercase",
                        children: "Discover"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        id: "screener",
                        className: `${buttonStyle} ${router.route.startsWith("/screener") && chosenButtonStyle}`,
                        onClick: handleNavButtonClicked,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(hi_.HiDocumentSearch, {
                                style: buttonIconStyle
                            }),
                            "Screener"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        id: "simulator",
                        className: `${buttonStyle} ${router.route.startsWith("/simulator") && chosenButtonStyle}`,
                        onClick: handleNavButtonClicked,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiStockLine, {
                                style: buttonIconStyle
                            }),
                            "Trade Simulator"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        id: "recommendation",
                        className: `${buttonStyle} ${router.route.startsWith("/recommendation") && chosenButtonStyle}`,
                        onClick: handleNavButtonClicked,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiMessageDetail, {
                                style: buttonIconStyle
                            }),
                            "Recommendations"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-slate-400 text-2xl ml-4 mt-2 uppercase",
                        children: "others"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        id: "",
                        className: `${buttonStyle}`,
                        onClick: handleNavButtonClicked,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineInfoCircle, {
                                style: buttonIconStyle
                            }),
                            "About us"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        className: `${buttonStyle} hover:bg-red-700`,
                        onClick: ()=>(0,react_.signOut)(),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineLogout, {
                                style: buttonIconStyle
                            }),
                            "Log out"
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const SideBar_SideBar = (SideBar);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-icons/vsc"
var vsc_ = __webpack_require__(382);
// EXTERNAL MODULE: ./src/utils/clientUtils.ts
var clientUtils = __webpack_require__(8879);
;// CONCATENATED MODULE: ./src/components/Error/Error.tsx




const Error = ({ message , onClose  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${clientUtils/* popupClass */.Dw} top-[15%] bg-beige-300 rounded-lg shadow-md`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "absolute top-2 right-2 pointer-events-auto",
                onClick: onClose,
                children: /*#__PURE__*/ jsx_runtime_.jsx(vsc_.VscChromeClose, {
                    style: {
                        height: "1.5rem",
                        width: "1.5rem"
                    }
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-4xl font-raleway font-semibold text-red-700 mb-4",
                children: "Error"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                className: "border-green-700"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "pt-6 text-xl font-raleway text-black",
                children: message
            })
        ]
    });
};
/* harmony default export */ const Error_Error = (Error);

// EXTERNAL MODULE: ./src/store/index.ts
var store = __webpack_require__(6790);
;// CONCATENATED MODULE: ./src/components/Wrapper/Wrapper.tsx





const Wrapper = ({ children  })=>{
    const { data: sessionData  } = (0,react_.useSession)({
        required: true
    });
    const { errorAppear , message , setDisappear  } = (0,store/* useError */.VI)();
    return sessionData && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-row",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(SideBar_SideBar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${errorAppear ? "pointer-events-none blur-sm" : ""} bg-beige-400 ml-[22.5%] w-main-screen min-h-screen`,
                children: children
            }),
            errorAppear && /*#__PURE__*/ jsx_runtime_.jsx(Error_Error, {
                message: message,
                onClose: ()=>setDisappear()
            })
        ]
    });
};
/* harmony default export */ const Wrapper_Wrapper = (Wrapper);

;// CONCATENATED MODULE: ./src/components/SearchBar/SearchBar.tsx



const SearchBar = /*#__PURE__*/ external_react_default().forwardRef(({ placeholder , onChange  }, ref)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-beige-200 h-14 w-full shadow-lg rounded-2xl flex flex-row items-center gap-2 pl-4 pr-6",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineSearch, {
                style: {
                    height: "1.8rem",
                    width: "1.8rem",
                    color: "#64748b"
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                className: "bg-transparent w-full outline-none font-raleway text-xl",
                placeholder: placeholder,
                ref: ref,
                onChange: onChange
            })
        ]
    });
});
SearchBar.displayName = "SearchBar";
/* harmony default export */ const SearchBar_SearchBar = (SearchBar);

;// CONCATENATED MODULE: ./src/components/TickerInfo/TickerInfo.tsx




const TickerInfo = ({ ticker , showButton =true  })=>{
    const [watchlisted, setWatchlisted] = (0,external_react_.useState)(false);
    const addToWatchlistQuery = trpc/* trpc.watchlist.addToWatchlist.useMutation */.S.watchlist.addToWatchlist.useMutation();
    const router = (0,router_.useRouter)();
    const container = (0,external_react_.useRef)(null);
    const handleWatchlist = ()=>{
        addToWatchlistQuery.mutate({
            ticker
        });
        setWatchlisted(true);
    };
    (0,external_react_.useEffect)(()=>{
        const script = document.createElement("script");
        script.src = "https://s3.tradingview.com/external-embedding/embed-widget-symbol-info.js";
        script.async = true;
        script.innerHTML = JSON.stringify({
            "symbol": ticker,
            "width": "100%",
            "locale": "en",
            "colorTheme": "light",
            "isTransparent": true
        });
        container.current.appendChild(script);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative bg-beige-200 rounded-xl shadow-lg",
        children: [
            showButton && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "absolute right-2 top-14 flex flex-row gap-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "bg-green-700 text-white font-raleway rounded-xl py-2 px-4 hover:scale-105",
                        onClick: ()=>router.push("/simulator/" + ticker),
                        children: "Trade"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: `bg-beige-700 text-white font-raleway rounded-xl py-2 px-4 ${watchlisted ? "pointer-events-none" : "hover:scale-105"}`,
                        onClick: handleWatchlist,
                        children: watchlisted ? "Watchlisted" : "Watchlist"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tradingview-widget-container",
                ref: container,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "tradingview-widget-container__widget"
                })
            })
        ]
    });
};
/* harmony default export */ const TickerInfo_TickerInfo = (TickerInfo);

// EXTERNAL MODULE: ./src/utils/constants.ts
var constants = __webpack_require__(2166);
// EXTERNAL MODULE: ./src/components/MultiRangeSlider/MultiRangeSlider.module.css
var MultiRangeSlider_module = __webpack_require__(2081);
var MultiRangeSlider_module_default = /*#__PURE__*/__webpack_require__.n(MultiRangeSlider_module);
;// CONCATENATED MODULE: ./src/components/MultiRangeSlider/MultiRangeSlider.tsx






const MultiRangeSlider = ({ onChange , size ="medium" , filterType  })=>{
    const { value , setValue  } = (0,store/* useScreenerFilter */.wX)();
    const minValRef = (0,external_react_.useRef)(null);
    const maxValRef = (0,external_react_.useRef)(null);
    const range = (0,external_react_.useRef)(null);
    const { min , max  } = constants/* screenerConstants */.aq[filterType];
    const getPercent = (0,external_react_.useCallback)((value)=>{
        if (size === "small") return (value - min) / (max - min) * 100;
        return Math.round((value - min) / (max - min) * 100);
    }, [
        min,
        max
    ]);
    // Set width of the range to decrease from the left side
    (0,external_react_.useEffect)(()=>{
        if (maxValRef.current) {
            const minPercent = getPercent(value[filterType].min);
            const maxPercent = getPercent(+maxValRef.current.value);
            if (range.current) {
                range.current.style.left = `${minPercent}%`;
                range.current.style.width = `${maxPercent - minPercent}%`;
            }
        }
    }, [
        value,
        getPercent,
        filterType
    ]);
    // Set width of the range to decrease from the right side 
    (0,external_react_.useEffect)(()=>{
        if (minValRef.current) {
            const minPercent = getPercent(+minValRef.current.value);
            const maxPercent = getPercent(value[filterType].max);
            if (range.current) {
                range.current.style.width = `${maxPercent - minPercent}%`;
            }
        }
    }, [
        value,
        getPercent,
        filterType
    ]);
    // // Get min and max values when their state changes
    // useEffect(() => {
    //   onChange && onChange({ min: value[filterType].min, max: value[filterType].max });
    // }, [value, onChange]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "h-full w-full flex flex-row items-center gap-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "h-10 w-16 border border-solid border-back bg-beige-400 rounded-md flex items-center justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "",
                    children: [
                        size === "large" && (value[filterType].min < min ? `<${(0,clientUtils/* nFormatter */.pF)(min, 0)}` : (0,clientUtils/* nFormatter */.pF)(value[filterType].min, 0)),
                        size === "medium" && value[filterType].min,
                        size === "small" && value[filterType].min
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "items-center justify-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "range",
                        min: size === "large" ? min - 1 : min,
                        step: size === "small" ? 0.01 : 1,
                        max: max,
                        value: value[filterType].min,
                        ref: minValRef,
                        onChange: (event)=>{
                            const inputValue = Math.min(+event.target.value, value[filterType].max - (size === "small" ? 0.01 : 1));
                            setValue({
                                ...value,
                                [filterType]: {
                                    ...value[filterType],
                                    min: inputValue
                                }
                            });
                            event.target.value = inputValue.toString();
                        },
                        className: `${(MultiRangeSlider_module_default()).thumb} ${(MultiRangeSlider_module_default()).thumbZ3} ${value[filterType].min > max - 100 && (MultiRangeSlider_module_default()).thumbZ5}`
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "range",
                        min: min,
                        max: size === "large" ? max + 1 : max,
                        value: value[filterType].max,
                        step: size === "small" ? 0.01 : 1,
                        ref: maxValRef,
                        onChange: (event)=>{
                            const inputValue = Math.max(+event.target.value, value[filterType].min + (size === "small" ? 0.01 : 1));
                            setValue({
                                ...value,
                                [filterType]: {
                                    ...value[filterType],
                                    max: inputValue
                                }
                            });
                            event.target.value = inputValue.toString();
                        },
                        className: `${(MultiRangeSlider_module_default()).thumb} ${(MultiRangeSlider_module_default()).thumbZ4}`
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `${(MultiRangeSlider_module_default()).slider}`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `${(MultiRangeSlider_module_default()).sliderTrack}`
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                ref: range,
                                className: `${(MultiRangeSlider_module_default()).sliderRange}`
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "h-10 w-16 border border-solid border-back bg-beige-400 rounded-md flex items-center justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "",
                    children: [
                        size === "large" && (value[filterType].max > max ? `>${(0,clientUtils/* nFormatter */.pF)(max, 0)}` : (0,clientUtils/* nFormatter */.pF)(value[filterType].max, 0)),
                        size === "medium" && value[filterType].max,
                        size === "small" && value[filterType].max
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const MultiRangeSlider_MultiRangeSlider = (MultiRangeSlider);

// EXTERNAL MODULE: ./src/components/DiscreteSlider/DiscreteSlider.module.css
var DiscreteSlider_module = __webpack_require__(6414);
var DiscreteSlider_module_default = /*#__PURE__*/__webpack_require__.n(DiscreteSlider_module);
;// CONCATENATED MODULE: ./src/components/DiscreteSlider/DiscreteSlider.tsx






const DiscreteSlider_MultiRangeSlider = ({ onChange , values , filterType  })=>{
    const { value , setValue  } = (0,store/* useScreenerFilter */.wX)();
    const minValRef = (0,external_react_.useRef)(null);
    const maxValRef = (0,external_react_.useRef)(null);
    const range = (0,external_react_.useRef)(null);
    const [min, max] = [
        0,
        values.length - 1
    ];
    const { max: maxVal , min: minVal  } = constants/* screenerConstants */.aq[filterType];
    const getPercent = (0,external_react_.useCallback)((value)=>{
        return Math.round((value - min) / (max - min) * 100);
    }, [
        min,
        max
    ]);
    const getLevel = (value)=>{
        return values.indexOf(value);
    };
    // Set width of the range to decrease from the left side
    (0,external_react_.useEffect)(()=>{
        if (maxValRef.current) {
            const minPercent = getPercent(getLevel(value[filterType].min));
            const maxPercent = getPercent(+maxValRef.current.value);
            if (range.current) {
                range.current.style.left = `${minPercent}%`;
                range.current.style.width = `${maxPercent - minPercent}%`;
            }
        }
    }, [
        value,
        getPercent,
        filterType
    ]);
    // Set width of the range to decrease from the right side 
    (0,external_react_.useEffect)(()=>{
        if (minValRef.current) {
            const minPercent = getPercent(+minValRef.current.value);
            const maxPercent = getPercent(getLevel(value[filterType].max));
            if (range.current) {
                range.current.style.width = `${maxPercent - minPercent}%`;
            }
        }
    }, [
        value,
        getPercent,
        filterType
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "h-full w-full flex flex-row items-center gap-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "h-10 w-16 border border-solid border-back bg-beige-400 rounded-md flex items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "",
                    children: value[filterType].min === values[0] ? `<${(0,clientUtils/* nFormatter */.pF)(minVal, 0)}` : (0,clientUtils/* nFormatter */.pF)(value[filterType].min, 0)
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "items-center justify-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "range",
                        min: min,
                        step: 1,
                        max: max,
                        value: getLevel(value[filterType].min),
                        ref: minValRef,
                        className: `${(DiscreteSlider_module_default()).thumb} ${(DiscreteSlider_module_default()).thumbZ3} ${value[filterType].min > max - 100 && (DiscreteSlider_module_default()).thumbZ5}`,
                        onChange: (event)=>{
                            const inputValue = Math.min(+event.target.value, getLevel(value[filterType].max) - 1);
                            setValue({
                                ...value,
                                [filterType]: {
                                    ...value[filterType],
                                    min: values[inputValue]
                                }
                            });
                            event.target.value = inputValue.toString();
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "range",
                        min: min,
                        max: max,
                        value: getLevel(value[filterType].max),
                        step: 1,
                        ref: maxValRef,
                        className: `${(DiscreteSlider_module_default()).thumb} ${(DiscreteSlider_module_default()).thumbZ4}`,
                        onChange: (event)=>{
                            const inputValue = Math.max(+event.target.value, getLevel(value[filterType].min) + 1);
                            setValue({
                                ...value,
                                [filterType]: {
                                    ...value[filterType],
                                    max: values[inputValue]
                                }
                            });
                            event.target.value = inputValue.toString();
                        }
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `${(DiscreteSlider_module_default()).slider}`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `${(DiscreteSlider_module_default()).sliderTrack}`
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                ref: range,
                                className: `${(DiscreteSlider_module_default()).sliderRange}`
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "h-10 w-16 border border-solid border-back bg-beige-400 rounded-md flex items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "",
                    children: value[filterType].max === values[values.length - 1] ? `>${(0,clientUtils/* nFormatter */.pF)(maxVal, 0)}` : (0,clientUtils/* nFormatter */.pF)(value[filterType].max, 0)
                })
            })
        ]
    });
};
/* harmony default export */ const DiscreteSlider = (DiscreteSlider_MultiRangeSlider);

;// CONCATENATED MODULE: ./src/components/Filter/Filter.tsx









const description = {
    "marketCap": "The total dollar market value of a company's outstanding shares of stock (Investopedia).",
    "avgVolume": "How many shares are traded per day (Investopedia).",
    "PE": "The ratio for valuing a company that measures its current share price relative to its earnings per share (EPS) (Investopedia).",
    "DE": "The ratio used to evaluate a company’s financial leverage and is calculated by dividing a company’s total liabilities by its shareholder equity (Investopedia).",
    "beta": "A measure of a stock's volatility in relation to the overall market. By definition, the market, such as the S&P 500 Index, has a beta of 1.0, and individual stocks are ranked according to how much they deviate from the market (Investopedia).",
    "price": "Indicate the current value to buyers and sellers (Investopedia)."
};
const Filter = ({ onClose , onSearch  })=>{
    const { value , setValue , resetValue  } = (0,store/* useScreenerFilter */.wX)();
    const [toggleDescription, setToggleDescription] = (0,external_react_.useState)({
        "marketCap": false,
        "avgVolume": false,
        "PE": false,
        "DE": false,
        "beta": false,
        "price": false
    });
    const handleSearch = async ()=>{
        await onSearch();
    };
    const handleReset = ()=>{
        resetValue();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${clientUtils/* popupClass */.Dw} top-[15%] bg-beige-300 rounded-lg shadow-md`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "absolute top-2 right-2 pointer-events-auto",
                onClick: onClose,
                children: /*#__PURE__*/ jsx_runtime_.jsx(vsc_.VscChromeClose, {
                    style: {
                        height: "1.5rem",
                        width: "1.5rem"
                    }
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-4xl font-raleway font-semibold text-green-700 mb-4",
                children: "Create Filters"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row my-2 p-3 bg-beige-200 rounded-md shadow-lg items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-2/5 flex flex-row items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-xl font-raleway mr-1",
                                children: "Market Capitalization"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                onMouseEnter: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "marketCap": true
                                    }),
                                onMouseLeave: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "marketCap": false
                                    }),
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillQuestionCircle, {
                                    style: {
                                        width: "1.2rem",
                                        height: "1.2rem"
                                    }
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative h-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `absolute top-[-10px] left-0 z-50 w-80 bg-beige-300 border-solid border-black border p-3 rounded-lg ${!toggleDescription["marketCap"] && "invisible"}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "font-raleway",
                                        children: description["marketCap"]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-3/5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(DiscreteSlider, {
                            filterType: "marketCap",
                            values: constants/* marketCapValues */.Vy
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row my-2 p-3 bg-beige-200 rounded-md shadow-lg items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-2/5 flex flex-row items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-xl font-raleway mr-1",
                                children: "Average Volume"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                onMouseEnter: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "avgVolume": true
                                    }),
                                onMouseLeave: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "avgVolume": false
                                    }),
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillQuestionCircle, {
                                    style: {
                                        width: "1.2rem",
                                        height: "1.2rem"
                                    }
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative h-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `absolute top-[-10px] left-0 z-50 w-80 bg-beige-300 border-solid border-black border p-3 rounded-lg ${!toggleDescription["avgVolume"] && "invisible"}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "font-raleway",
                                        children: description["avgVolume"]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-3/5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(DiscreteSlider, {
                            filterType: "avgVolume",
                            values: constants/* avgVolumeValues */.Oc
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row my-2 p-3 bg-beige-200 rounded-md shadow-lg items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-2/5 flex flex-row items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-xl font-raleway mr-1",
                                children: "Price-to-Earnings"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                onMouseEnter: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "PE": true
                                    }),
                                onMouseLeave: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "PE": false
                                    }),
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillQuestionCircle, {
                                    style: {
                                        width: "1.2rem",
                                        height: "1.2rem"
                                    }
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative h-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `absolute top-[-10px] left-0 z-50 w-80 bg-beige-300 border-solid border-black border p-3 rounded-lg ${!toggleDescription["PE"] && "invisible"}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "font-raleway",
                                        children: description["PE"]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-3/5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(MultiRangeSlider_MultiRangeSlider, {
                            filterType: "PE"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row my-2 p-3 bg-beige-200 rounded-md shadow-lg items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-2/5 flex flex-row items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-xl font-raleway mr-1",
                                children: "Debt-to-Equity"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                onMouseEnter: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "DE": true
                                    }),
                                onMouseLeave: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "DE": false
                                    }),
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillQuestionCircle, {
                                    style: {
                                        width: "1.2rem",
                                        height: "1.2rem"
                                    }
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative h-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `absolute top-[-10px] left-0 z-50 w-80 bg-beige-300 border-solid border-black border p-3 rounded-lg ${!toggleDescription["DE"] && "invisible"}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "font-raleway",
                                        children: description["DE"]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-3/5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(MultiRangeSlider_MultiRangeSlider, {
                            filterType: "DE"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row my-2 p-3 bg-beige-200 rounded-md shadow-lg items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-2/5 flex flex-row items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-xl font-raleway mr-1",
                                children: "Beta"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                onMouseEnter: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "beta": true
                                    }),
                                onMouseLeave: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "beta": false
                                    }),
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillQuestionCircle, {
                                    style: {
                                        width: "1.2rem",
                                        height: "1.2rem"
                                    }
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative h-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `absolute top-[-10px] left-0 z-50 w-80 bg-beige-300 border-solid border-black border p-3 rounded-lg ${!toggleDescription["beta"] && "invisible"}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "font-raleway",
                                        children: description["beta"]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-3/5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(MultiRangeSlider_MultiRangeSlider, {
                            size: "small",
                            filterType: "beta"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row my-2 p-3 bg-beige-200 rounded-md shadow-lg items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-2/5 flex flex-row items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-xl font-raleway mr-1",
                                children: "Price"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                onMouseEnter: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "price": true
                                    }),
                                onMouseLeave: ()=>setToggleDescription({
                                        ...toggleDescription,
                                        "price": false
                                    }),
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillQuestionCircle, {
                                    style: {
                                        width: "1.2rem",
                                        height: "1.2rem"
                                    }
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative h-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `absolute top-[-10px] left-0 z-50 w-80 bg-beige-300 border-solid border-black border p-3 rounded-lg ${!toggleDescription["price"] && "invisible"}`,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "font-raleway",
                                        children: description["price"]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-3/5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(MultiRangeSlider_MultiRangeSlider, {
                            filterType: "price"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full flex flex-row justify-end gap-4 mt-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "w-24 px-2 py-2 text-white bg-green-700 rounded-lg text-xl hover:scale-105",
                        onClick: handleSearch,
                        children: "Search"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "w-24 px-2 py-2 text-white bg-red-700 rounded-lg text-xl hover:scale-105",
                        onClick: handleReset,
                        children: "Clear"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Filter_Filter = (Filter);

;// CONCATENATED MODULE: ./src/components/MiniChart/MiniChart.tsx



const MiniChart = ({ ticker  })=>{
    const router = (0,router_.useRouter)();
    const container = (0,external_react_.useRef)(null);
    const [scripted, setScripted] = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        if (!scripted) {
            setScripted(true);
            const script = document.createElement("script");
            script.src = "https://s3.tradingview.com/external-embedding/embed-widget-mini-symbol-overview.js";
            script.async = true;
            script.innerHTML = JSON.stringify({
                "symbol": ticker,
                "width": "100%",
                "height": "100%",
                "locale": "en",
                "dateRange": "12M",
                "colorTheme": "light",
                "trendLineColor": "rgba(41, 98, 255, 1)",
                "underLineColor": "rgba(41, 98, 255, 0.3)",
                "underLineBottomColor": "rgba(41, 98, 255, 0)",
                "isTransparent": true,
                "autosize": false,
                "largeChartUrl": ""
            });
            container.current?.appendChild(script);
        }
    }, [
        ticker
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "rounded-lg bg-beige-200 h-60 min-w-[300px] px-2 py-3 relative shadow-dark shadow-slate-black",
        children: [
            scripted && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute right-14 top-3",
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "rounded-lg bg-green-700 text-white text-sm py-1 px-3 hover:scale-105",
                    onClick: ()=>router.push("/simulator/" + ticker),
                    children: "Trade"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tradingview-widget-container",
                ref: container,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "tradingview-widget-container__widget"
                })
            })
        ]
    });
};
/* harmony default export */ const MiniChart_MiniChart = (MiniChart);

;// CONCATENATED MODULE: ./src/components/TrendingTickers/TrendingTickers.tsx




const TrendingTickers = ()=>{
    const { data: tickers  } = trpc/* trpc.ticker.getTrending.useQuery */.S.ticker.getTrending.useQuery();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: " bg-beige-300 px-6 py-6 shadow-lg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: " overflow-x-scroll whitespace-nowrap pb-6 flex flex-row gap-6 ",
            children: tickers?.map((ticker)=>/*#__PURE__*/ jsx_runtime_.jsx(MiniChart_MiniChart, {
                    ticker: ticker
                }, `chart for ${ticker}`))
        })
    });
};
/* harmony default export */ const TrendingTickers_TrendingTickers = (TrendingTickers);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/HeaderImage/HeaderImage.tsx



const HeaderImage = ({ src , alt  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "relative h-72 w-full overflow-hidden",
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: src,
            alt: alt,
            style: {
                "objectFit": "cover"
            },
            fill: true
        })
    });
};
/* harmony default export */ const HeaderImage_HeaderImage = (HeaderImage);

;// CONCATENATED MODULE: ./src/components/MarketInfo/MarketInfo.tsx


const MarketInfo = ()=>{
    const container = (0,external_react_.useRef)(null);
    (0,external_react_.useEffect)(()=>{
        const script = document.createElement("script");
        script.src = "https://s3.tradingview.com/external-embedding/embed-widget-hotlists.js";
        script.async = true;
        script.innerHTML = JSON.stringify({
            "colorTheme": "light",
            "dateRange": "12M",
            "exchange": "US",
            "showChart": true,
            "locale": "en",
            "largeChartUrl": "",
            "isTransparent": true,
            "showSymbolLogo": true,
            "showFloatingTooltip": false,
            "width": "100%",
            "height": "100%",
            "plotLineColorGrowing": "rgba(57, 81, 68, 1)",
            "plotLineColorFalling": "rgba(57, 81, 68, 1)",
            "gridLineColor": "rgba(240, 243, 250, 0)",
            "scaleFontColor": "rgba(106, 109, 120, 1)",
            "belowLineFillColorGrowing": "rgba(57, 81, 68, 0.2)",
            "belowLineFillColorFalling": "rgba(57, 81, 68, 0.2)",
            "belowLineFillColorGrowingBottom": "rgba(57, 81, 68, 0.2)",
            "belowLineFillColorFallingBottom": "rgba(57, 81, 68, 0.2)",
            "symbolActiveColor": "rgba(57, 81, 68, 0.2)"
        });
        container.current.appendChild(script);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full h-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "tradingview-widget-container",
            ref: container,
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tradingview-widget-container__widget"
            })
        })
    });
};
/* harmony default export */ const MarketInfo_MarketInfo = (MarketInfo);

;// CONCATENATED MODULE: ./src/components/TickerChart/TickerChart.tsx



const createCode = (length)=>{
    let result = "";
    const characters = "abcdefghijklmnopqrstuvwxyz0123456789";
    const charactersLength = characters.length;
    for(let i = 0; i < length; i++){
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
};
const TickerChart = ({ ticker  })=>{
    const router = (0,router_.useRouter)();
    const [code, setCode] = (0,external_react_.useState)(createCode(5));
    const container = (0,external_react_.useRef)(null);
    (0,external_react_.useEffect)(()=>{
        setCode(createCode(5));
    }, [
        router
    ]);
    (0,external_react_.useEffect)(()=>{
        // const firstScript = document.createElement('script');
        // firstScript.src = "https://s3.tradingview.com/tv.js"
        const secondScript = document.createElement("script");
        secondScript.innerHTML = "new TradingView.MediumWidget(" + JSON.stringify({
            "symbols": [
                [
                    ticker
                ]
            ],
            "chartOnly": true,
            "width": "100%",
            "height": "100%",
            "locale": "en",
            "colorTheme": "light",
            "autosize": true,
            "showVolume": false,
            "hideDateRanges": false,
            "hideMarketStatus": false,
            "scalePosition": "right",
            "scaleMode": "Normal",
            "fontFamily": "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
            "fontSize": "10",
            "noTimeScale": false,
            "valuesTracking": "1",
            "chartType": "line",
            "backgroundColor": "rgba(0, 0, 0, 0)",
            "container_id": `tradingview_19283`
        }) + ")";
        // container.current!.appendChild(firstScript);
        container.current.appendChild(secondScript);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full h-full min-h-[20rem]",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "tradingview-widget-container",
            ref: container,
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: `tradingview_19283`
            })
        })
    });
};
/* harmony default export */ const TickerChart_TickerChart = (TickerChart);

;// CONCATENATED MODULE: ./src/components/TickerTechnicalAnalysis/TickerTechnicalAnalysis.tsx


const TickerTechnicalAnalysis = ({ ticker  })=>{
    const container = (0,external_react_.useRef)(null);
    (0,external_react_.useEffect)(()=>{
        const script = document.createElement("script");
        script.src = "https://s3.tradingview.com/external-embedding/embed-widget-technical-analysis.js";
        script.async = true;
        script.innerHTML = JSON.stringify({
            "interval": "1m",
            "width": "100%",
            "isTransparent": true,
            "height": "100%",
            "symbol": ticker,
            "showIntervalTabs": true,
            "locale": "en",
            "colorTheme": "light"
        });
        container.current?.appendChild(script);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full h-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "tradingview-widget-container",
            ref: container,
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tradingview-widget-container__widget"
            })
        })
    });
};
/* harmony default export */ const TickerTechnicalAnalysis_TickerTechnicalAnalysis = (TickerTechnicalAnalysis);

;// CONCATENATED MODULE: ./src/components/PreviewOrder/PreviewOrder.tsx






const PreviewOrder = ({ type , ticker , price , quantity , onClose  })=>{
    const router = (0,router_.useRouter)();
    const userQuery = trpc/* trpc.user.getUserInfo.useQuery */.S.user.getUserInfo.useQuery();
    const makeTransaction = trpc/* trpc.transaction.makeTransaction.useMutation */.S.transaction.makeTransaction.useMutation({
        onSuccess: ()=>{
            router.push("/history");
            userQuery.refetch();
        }
    });
    const handleSubmit = async ()=>{
        makeTransaction.mutate({
            ticker,
            price,
            quantity,
            type
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `${clientUtils/* popupClass */.Dw} top-[8%]`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative mx-10 py-10 px-10 bg-beige-300 rounded-xl shadow-md",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "absolute top-2 right-2 pointer-events-auto",
                    onClick: onClose,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(vsc_.VscChromeClose, {
                        style: {
                            height: "1.5rem",
                            width: "1.5rem"
                        }
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "mt-12 text-4xl font-raleway font-medium text-green-700 mb-4",
                    children: "Preview Order"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: "border-green-700"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mt-6 flex flex-row mx-0 justify-evenly",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col gap-2 items-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                    className: "font-raleway text-2xl font-semibold text-slate-700 capitalize",
                                    children: [
                                        "Stock: ",
                                        type
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-raleway text-2xl",
                                    children: ticker
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col gap-2 items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "font-raleway text-2xl font-semibold text-slate-700 capitalize",
                                    children: "Quantity"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-raleway text-2xl",
                                    children: quantity
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-20 mb-5 mx-12 flex flex-col gap-8",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(OrderRow, {
                                    name: "Est. Price",
                                    value: price
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(OrderRow, {
                                    name: "Quantity",
                                    value: quantity,
                                    isCurrency: false
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(OrderRow, {
                                    name: "Comimssion",
                                    value: 0
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                            className: "border-green-700"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mt-5 mx-12 flex flex-col gap-8",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(OrderRow, {
                                name: "Est. Total",
                                value: quantity * price
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mt-20 flex flex-row justify-end gap-6",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "w-32 py-3 bg-red-700 rounded-lg font-raleway text-xl text-white hover:scale-105",
                            onClick: onClose,
                            children: "Change"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "w-32 py-3 bg-green-700 rounded-lg font-raleway text-xl text-white hover:scale-105",
                            onClick: handleSubmit,
                            children: "Submit"
                        })
                    ]
                })
            ]
        })
    });
};
const OrderRow = ({ name , value , isCurrency =true  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-row",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "w-3/4 font-raleway text-2xl",
                children: name
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "w-1/4 font-raleway text-2xl",
                children: `${isCurrency ? "$" : ""}${value.toLocaleString("en-US")}`
            })
        ]
    });
};
/* harmony default export */ const PreviewOrder_PreviewOrder = (PreviewOrder);

;// CONCATENATED MODULE: ./src/components/SaveScreener/SaveScreener.tsx






const SaveScreener = ({ onClose  })=>{
    // Store
    const { value  } = (0,store/* useScreenerFilter */.wX)();
    // Refs
    const inputRef = (0,external_react_.useRef)(null);
    // Stataes
    const [error, setError] = (0,external_react_.useState)(false);
    // Queries/Mutations
    const saveScreenerQuery = trpc/* trpc.screener.saveScreener.useMutation */.S.screener.saveScreener.useMutation({
        onSuccess: ()=>{
            onClose();
        }
    });
    const handleSave = ()=>{
        const name = inputRef.current?.value;
        if (!name) {
            setError(true);
            return;
        }
        const queryValue = (0,clientUtils/* formatScreener */.yx)(value);
        saveScreenerQuery.mutate({
            name,
            ...queryValue
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${clientUtils/* popupClass */.Dw} top-[15%] bg-beige-300 rounded-lg shadow-md`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "absolute top-2 right-2 pointer-events-auto",
                onClick: onClose,
                children: /*#__PURE__*/ jsx_runtime_.jsx(vsc_.VscChromeClose, {
                    style: {
                        height: "1.5rem",
                        width: "1.5rem"
                    }
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-4xl font-raleway font-semibold text-green-700",
                children: "Save Screener"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                className: "border-green-700 my-10"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                className: "flex flex-col gap-2 font-raleway text-2xl text-beige-700",
                children: [
                    "Screener Name",
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: " font-raleway text-xl text-slate-800 bg-transparent border-b border-slate-400 outline-none",
                        type: "text",
                        placeholder: "e.g Small stock",
                        ref: inputRef
                    })
                ]
            }),
            error && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "font-raleway text-red-700",
                children: "Please type the name of the filter"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative mx-0 mt-6",
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "float-right py-3 w-40 bg-green-700 font-raleway text-white text-xl rounded-lg hover:scale-105",
                    onClick: handleSave,
                    children: "Save"
                })
            })
        ]
    });
};
/* harmony default export */ const SaveScreener_SaveScreener = (SaveScreener);

;// CONCATENATED MODULE: ./src/components/SavedScreeners/SavedScreenerRow/SavedScreenerRow.tsx


const ScreenerRow = /*#__PURE__*/ (0,external_react_.forwardRef)(({ index , screenerId , name , date , onClick  }, ref)=>{
    const [selected, setSelected] = (0,external_react_.useState)(false);
    (0,external_react_.useImperativeHandle)(ref, ()=>({
            removeSelected: ()=>setSelected(false),
            getId: ()=>screenerId
        }), []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
        className: `flex flex-row items-center text-left rounded-md px-4 h-12 ${selected && "bg-beige-500"}`,
        onClick: ()=>{
            setSelected(true);
            onClick(index);
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-[60%]",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: `font-raleway text-xl`,
                    children: name
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-[40%]",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: `font-raleway text-xl`,
                    children: date?.toLocaleDateString("en-US")
                })
            })
        ]
    });
});
ScreenerRow.displayName = "Screener Row";
/* harmony default export */ const SavedScreenerRow = (ScreenerRow);

;// CONCATENATED MODULE: ./src/components/SavedScreeners/SavedScreeners.tsx








const SavedScreeners = ({ onClose , onSearch  })=>{
    // Store
    const { value , setValue  } = (0,store/* useScreenerFilter */.wX)();
    // Refs
    const rowRefs = (0,external_react_.useRef)([]);
    // States
    const [available, setAvailable] = (0,external_react_.useState)(false);
    const [screeners, setScreeners] = (0,external_react_.useState)([]);
    const [selectedIndex, setSelectedIndex] = (0,external_react_.useState)(-1);
    const [id, setId] = (0,external_react_.useState)(-1);
    const [fetchById, setFetchById] = (0,external_react_.useState)(false);
    // Change for value
    (0,external_react_.useEffect)(()=>{
        if (fetchById) {
            setFetchById(false);
            onSearch();
        }
    }, [
        value
    ]);
    // Queries
    const savedScreenersQuery = trpc/* trpc.screener.viewScreeners.useQuery */.S.screener.viewScreeners.useQuery(undefined, {
        onSuccess: (data)=>{
            setAvailable(true);
            setScreeners(data);
        }
    });
    const screenerQuery = trpc/* trpc.screener.getScreenerById.useQuery */.S.screener.getScreenerById.useQuery({
        id
    }, {
        enabled: fetchById,
        onSuccess: (data)=>{
            setValue((0,clientUtils/* reverseFormatScreener */.QU)(data));
        }
    });
    const deleteScreener = trpc/* trpc.screener.deleteScreener.useMutation */.S.screener.deleteScreener.useMutation({
        onSuccess: ()=>{
            savedScreenersQuery.refetch();
        }
    });
    const handleUpdate = (index)=>{
        if (index === selectedIndex) return;
        rowRefs.current[selectedIndex]?.removeSelected();
        setSelectedIndex(index);
    };
    const handleSearch = ()=>{
        if (selectedIndex === -1) return;
        const id = screeners[selectedIndex]?.id;
        if (!id) return;
        setId(parseInt(id));
        setFetchById(true);
    };
    const handleDelete = ()=>{
        if (selectedIndex === -1) return;
        const id = rowRefs.current[selectedIndex]?.getId();
        if (!id) return;
        deleteScreener.mutate({
            id
        });
        setSelectedIndex(-1);
        setScreeners(screeners.filter((screener, index)=>index !== selectedIndex));
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `${clientUtils/* popupClass */.Dw} top-[10%]`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative bg-beige-300 rounded-lg shadow-md mx-20 px-8 pt-20",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "absolute top-2 right-2 pointer-events-auto",
                    onClick: onClose,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(vsc_.VscChromeClose, {
                        style: {
                            height: "1.5rem",
                            width: "1.5rem"
                        }
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "text-4xl font-raleway font-semibold text-green-700",
                    children: "Saved Screeners"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: "border-green-700 mt-6 mb-20"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `flex flex-row items-center rounded-md px-4 h-12`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "w-[60%]",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: `font-raleway text-xl font-semibold`,
                                        children: "Name"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "w-[40%]",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: `font-raleway text-xl font-semibold`,
                                        children: "Date"
                                    })
                                })
                            ]
                        }),
                        available ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex flex-col overflow-scroll h-[16rem] max-h-[16rem]",
                            children: screeners?.map((screener, index)=>/*#__PURE__*/ jsx_runtime_.jsx(SavedScreenerRow, {
                                    index: index,
                                    screenerId: parseInt(screener.id),
                                    name: screener.name,
                                    date: screener.date,
                                    ref: (ref)=>{
                                        if (ref !== null) rowRefs.current[index] = ref;
                                    },
                                    onClick: handleUpdate
                                }, `key for screener id ${screener.id}`))
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mx-0 flex justify-center mt-10",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_spinners_.ClipLoader, {
                                color: "#395144"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mx-0 relative",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "float-right flex flex-row gap-2 my-6",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "w-28 py-2 bg-green-700 rounded-lg font-raleway text-white text-xl hover:scale-105",
                                onClick: handleSearch,
                                children: "Search"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "w-28 py-2 bg-red-700 rounded-lg font-raleway text-white text-xl hover:scale-105",
                                onClick: handleDelete,
                                children: "Delete"
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const SavedScreeners_SavedScreeners = (SavedScreeners);

;// CONCATENATED MODULE: ./src/components/PortfolioOverview/PortfolioInfoRow/PortfolioInfoCell.tsx



const questionPromptClass = {
    height: "1rem",
    width: "1rem"
};
const titleClass = "font-raleway text-lg font-semibold uppercase text-beige-700";
const numericTextClass = "font-raleway text-3xl font-medium";
const PortfolioInfoCell = ({ title , helper , sign =false , positive =true , value , subvalue  })=>{
    const [openHelper, setOpenHelper] = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-1/2 flex flex-col",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row gap-1",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: `${titleClass}`,
                        children: title
                    }),
                    helper && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center",
                        onMouseMove: ()=>setOpenHelper(true),
                        onMouseLeave: ()=>setOpenHelper(false),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillQuestionCircle, {
                                style: questionPromptClass
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative",
                                children: openHelper && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "absolute z-10 w-80 bg-beige-300 border rounded-lg p-2",
                                    children: helper
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: `${numericTextClass} ${sign && (positive ? "text-green-700" : "text-red-700")}`,
                children: `${sign ? positive ? "+" : "-" : ""} ${value}`
            }),
            subvalue && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: `font-raleway text-xl ml-5 ${sign && (positive ? "text-green-700" : "text-red-700")}`,
                children: `(${subvalue})`
            })
        ]
    });
};
/* harmony default export */ const PortfolioInfoRow_PortfolioInfoCell = (PortfolioInfoCell);

;// CONCATENATED MODULE: ./src/components/PortfolioOverview/PortfolioOverview.tsx






const PortfolioOverview_questionPromptClass = {
    height: "1rem",
    width: "1rem"
};
const rowClass = "flex flex-row gap-2 h-1/3";
const currencyFormatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD"
});
const percentageFormatter = new Intl.NumberFormat("en-US", {
    style: "percent",
    minimumFractionDigits: 2
});
const PortfolioOverview = ()=>{
    // States
    const [dataAvailable, setDataAvailable] = (0,external_react_.useState)(false);
    const [holdingsAvailable, setHoldingsAvailable] = (0,external_react_.useState)(false);
    const [cashAvailable, setCashAvailable] = (0,external_react_.useState)(false);
    const [accountValueHelper, setAccountValueHelper] = (0,external_react_.useState)(false);
    const [cash, setCash] = (0,external_react_.useState)(10000);
    const [totalHoldingsValue, setTotalHoldingsValue] = (0,external_react_.useState)(0);
    const [portfolioAge, setPortfolioAge] = (0,external_react_.useState)(0);
    const [firstPortfolioValue, setFirstPortfolioValue] = (0,external_react_.useState)(10000);
    const [yesterdayPortfolioValue, setYesterdayPortfolioValue] = (0,external_react_.useState)(10000);
    // Queries/Mutations
    trpc/* trpc.user.getUserInfo.useQuery */.S.user.getUserInfo.useQuery(undefined, {
        onSuccess: (data)=>{
            setCash(data.cash);
            setCashAvailable(true);
        }
    });
    trpc/* trpc.portfolio.getHoldings.useQuery */.S.portfolio.getHoldings.useQuery(undefined, {
        onSuccess: (data)=>{
            let tv = 0; // total value
            let tp = 0; // total purchase
            data.forEach((ticker)=>{
                tv += (ticker.currentPrice ? ticker.currentPrice : 0) * ticker.quantity;
                tp += ticker.purchasePrice * ticker.quantity;
            });
            setTotalHoldingsValue(tv);
            setHoldingsAvailable(true);
        }
    });
    trpc/* trpc.portfolio.getTimeSeriesValues.useQuery */.S.portfolio.getTimeSeriesValues.useQuery(undefined, {
        onSuccess: (data)=>{
            if (data[0]) {
                setFirstPortfolioValue(data[0].value);
                setPortfolioAge(Math.floor((new Date().getTime() - data[0].date.getTime()) / (1000 * 3600 * 24)));
            }
            const yesterday = data[data.length - 2];
            if (yesterday) setYesterdayPortfolioValue(yesterday.value);
        }
    });
    (0,external_react_.useEffect)(()=>{
        if (cashAvailable && holdingsAvailable) setDataAvailable(true);
    }, [
        cashAvailable,
        holdingsAvailable
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `h-full w-full bg-beige-300 shadow-lg flex flex-col px-6 py-6`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col mb-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row gap-2 items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "font-raleway text-2xl text-beige-700 font-semibold uppercase ",
                                children: "Account Value"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center",
                                onMouseMove: ()=>setAccountValueHelper(true),
                                onMouseLeave: ()=>setAccountValueHelper(false),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillQuestionCircle, {
                                        style: PortfolioOverview_questionPromptClass
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "relative",
                                        children: accountValueHelper && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "absolute z-10 w-80 bg-beige-300 border rounded-lg p-2",
                                            children: clientUtils/* portfolioHelperMessages.accountValue */.kc.accountValue
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-raleway text-4xl font-semibold",
                        children: dataAvailable ? currencyFormatter.format(totalHoldingsValue + cash) : "loading..."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col justify-around gap-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: rowClass,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(PortfolioInfoRow_PortfolioInfoCell, {
                                title: "Today's Change",
                                sign: true,
                                positive: dataAvailable ? totalHoldingsValue + cash >= yesterdayPortfolioValue : true,
                                value: dataAvailable ? currencyFormatter.format(Math.abs(totalHoldingsValue + cash - yesterdayPortfolioValue)) : "loading...",
                                subvalue: dataAvailable ? percentageFormatter.format(Math.abs(totalHoldingsValue + cash - yesterdayPortfolioValue) / yesterdayPortfolioValue) : ""
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(PortfolioInfoRow_PortfolioInfoCell, {
                                title: "Total Gain/Loss",
                                sign: true,
                                positive: dataAvailable ? totalHoldingsValue + cash - firstPortfolioValue >= 0 : true,
                                value: dataAvailable ? currencyFormatter.format(Math.abs(totalHoldingsValue + cash - firstPortfolioValue)) : "loading..."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: rowClass,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(PortfolioInfoRow_PortfolioInfoCell, {
                                title: "Buying Power",
                                value: dataAvailable ? currencyFormatter.format(cash + totalHoldingsValue / 2) : "loading...",
                                helper: clientUtils/* portfolioHelperMessages.buyingPower */.kc.buyingPower
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(PortfolioInfoRow_PortfolioInfoCell, {
                                title: "Cash",
                                value: dataAvailable ? currencyFormatter.format(cash) : "loading...",
                                helper: clientUtils/* portfolioHelperMessages.cash */.kc.cash
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: rowClass,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(PortfolioInfoRow_PortfolioInfoCell, {
                                title: "Cum. Return",
                                sign: true,
                                positive: dataAvailable ? cash + totalHoldingsValue - firstPortfolioValue >= 0 : true,
                                value: dataAvailable ? percentageFormatter.format(Math.abs(cash + totalHoldingsValue - firstPortfolioValue) / firstPortfolioValue) : "loading...",
                                helper: clientUtils/* portfolioHelperMessages.cummulativeReturn */.kc.cummulativeReturn
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(PortfolioInfoRow_PortfolioInfoCell, {
                                title: "Annual Return",
                                sign: true,
                                positive: dataAvailable ? cash + totalHoldingsValue - firstPortfolioValue >= 0 : true,
                                value: dataAvailable ? percentageFormatter.format(Math.abs((1 + (cash + totalHoldingsValue - firstPortfolioValue) / firstPortfolioValue) ** (365 / portfolioAge) - 1)) : "loading...",
                                helper: clientUtils/* portfolioHelperMessages.annualReturn */.kc.annualReturn
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const PortfolioOverview_PortfolioOverview = (PortfolioOverview);

;// CONCATENATED MODULE: ./src/components/HoldingsInformation/HoldingsRow/HoldingsRow.tsx



const cellClass = "flex items-center";
const cellTextClass = "font-raleway text-lg font-medium capitalize";
const HoldingsRow = ({ symbol , company , currentPrice , purchasePrice , quantity  })=>{
    // Router
    const router = (0,router_.useRouter)();
    // States
    const totalValue = (currentPrice ? currentPrice : 0) * quantity;
    const buyValue = purchasePrice * quantity;
    const totalChange = totalValue - buyValue;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "border-slate-400 flex flex-row h-12 px-4 mx-0",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${cellClass} w-[10%]`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    className: `${cellTextClass} text-beige-700`,
                    children: symbol
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${cellClass} w-[18%]`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    className: `${cellTextClass}`,
                    children: company
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${cellClass} w-[15%]`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    className: `${cellTextClass}`,
                    children: currentPrice ? currentPrice : "Data not available"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${cellClass} w-[15%]`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    className: `${cellTextClass}`,
                    children: purchasePrice.toLocaleString("en-US", {
                        maximumFractionDigits: 2
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${cellClass} w-[10%]`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    className: `${cellTextClass}`,
                    children: quantity
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${cellClass} w-[10%]`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    className: `${cellTextClass}`,
                    children: totalValue.toLocaleString("en-US", {
                        maximumFractionDigits: 2
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${cellClass} w-[15%]`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    className: `${cellTextClass} ${totalChange >= 0 ? "text-green-700" : "text-red-700"}`,
                    children: totalChange.toLocaleString("en-US", {
                        maximumFractionDigits: 2
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${cellClass} w-[7%]`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "w-full font-raleway text-lg text-white px-3 py-2 bg-green-700 rounded-lg hover:scale-105",
                    onClick: ()=>router.push(`/simulator/${symbol}`),
                    children: "Trade"
                })
            })
        ]
    });
};
/* harmony default export */ const HoldingsRow_HoldingsRow = (HoldingsRow);

;// CONCATENATED MODULE: ./src/components/HoldingsInformation/HoldingsInformation.tsx




const columnNameClass = "font-raleway text-lg font-semibold capitalize";
const HoldingsInformation = ()=>{
    const [totalValue, setTotalValue] = (0,external_react_.useState)(0);
    const [totalPurchase, setTotalPurchase] = (0,external_react_.useState)(0);
    const [totalChange, setTotalChange] = (0,external_react_.useState)(0);
    const [holdingsDataAvailable, setHoldingsDataAvailable] = (0,external_react_.useState)(false);
    const [holdings, setHoldings] = (0,external_react_.useState)([]);
    trpc/* trpc.portfolio.getHoldings.useQuery */.S.portfolio.getHoldings.useQuery(undefined, {
        onSuccess: (data)=>{
            setHoldings(data);
        }
    });
    (0,external_react_.useEffect)(()=>{
        let tv = 0 // totalValue
        ;
        let tp = 0 // totalPurchase
        ;
        setHoldingsDataAvailable(true);
        holdings.forEach((ticker)=>{
            tv += (ticker.currentPrice ? ticker.currentPrice : 0) * ticker.quantity;
            tp += ticker.purchasePrice * ticker.quantity;
        });
        setTotalValue(tv);
        setTotalPurchase(tp);
        setTotalChange(tv - tp);
    }, [
        holdings
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `w-full h-full bg-beige-300 shadow-lg px-4 pt-4 pb-4`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row gap-8",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "font-raleway text-lg uppercase text-beige-700",
                                children: "Total Value"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: `font-raleway text-xl font-semibold`,
                                children: `$${totalValue.toLocaleString("en-US")}`
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "font-raleway text-lg uppercase text-beige-700",
                                children: "Total Gains/Loss"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: `font-raleway text-xl font-semibold ${totalChange >= 0 ? "text-green-700" : "text-red-700"}`,
                                children: `${totalChange >= 0 ? "+" : "-"} $${Math.abs(totalChange).toLocaleString("en-US")} (${(totalPurchase > 0 ? totalChange / totalPurchase * 100 : 0).toLocaleString("en-US")}%)`
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "border-slate-400 border-b border-t flex flex-row px-4 py-3 mt-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[10%]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: `${columnNameClass}`,
                            children: "Symbol"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[18%]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: `${columnNameClass}`,
                            children: "Company Name"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[15%]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: `${columnNameClass}`,
                            children: "Current Price"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[15%]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: `${columnNameClass}`,
                            children: "Purchase Price"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[10%]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: `${columnNameClass}`,
                            children: "Quantity"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[10%]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: `${columnNameClass}`,
                            children: "Total value"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[15%]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: `${columnNameClass}`,
                            children: "Total Gain/Loss"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[7%] text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: `${columnNameClass}`,
                            children: "Action"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex items-center mt-4",
                children: holdingsDataAvailable ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-col w-full gap-2",
                    children: holdings.map((ticker)=>/*#__PURE__*/ jsx_runtime_.jsx(HoldingsRow_HoldingsRow, {
                            symbol: ticker.ticker,
                            company: ticker.company,
                            currentPrice: ticker.currentPrice,
                            purchasePrice: ticker.purchasePrice,
                            quantity: ticker.quantity
                        }, `key for Holdings Row of ${ticker.ticker}`))
                }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {})
            })
        ]
    });
};
/* harmony default export */ const HoldingsInformation_HoldingsInformation = (HoldingsInformation);

;// CONCATENATED MODULE: ./src/components/TickerBanner/TickerBanner.tsx


const TickerBanner = ()=>{
    const container = (0,external_react_.useRef)(null);
    (0,external_react_.useEffect)(()=>{
        const script = document.createElement("script");
        script.src = "https://s3.tradingview.com/external-embedding/embed-widget-tickers.js";
        script.async = true;
        script.innerHTML = JSON.stringify({
            "symbols": [
                {
                    "proName": "FOREXCOM:SPXUSD",
                    "title": "S&P 500"
                },
                {
                    "proName": "FOREXCOM:NSXUSD",
                    "title": "US 100"
                },
                {
                    "proName": "FX_IDC:EURUSD",
                    "title": "EUR/USD"
                },
                {
                    "proName": "BITSTAMP:BTCUSD",
                    "title": "Bitcoin"
                },
                {
                    "proName": "BITSTAMP:ETHUSD",
                    "title": "Ethereum"
                }
            ],
            "colorTheme": "light",
            "isTransparent": true,
            "showSymbolLogo": true,
            "locale": "en"
        });
        container.current.appendChild(script);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "tradingview-widget-container",
            ref: container,
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tradingview-widget-container__widget"
            })
        })
    });
};
/* harmony default export */ const TickerBanner_TickerBanner = (TickerBanner);

;// CONCATENATED MODULE: ./src/components/MarketPerformance/MarketPerformance.tsx


let tvScriptLoadingPromise;
const MarketPerformance = ()=>{
    const onLoadScriptRef = (0,external_react_.useRef)();
    (0,external_react_.useEffect)(()=>{
        const createWidget = ()=>{
            if (document.getElementById("tradingview_6cee2") && "TradingView" in window) {
                new window.TradingView.MediumWidget({
                    symbols: [
                        [
                            "S&P 500",
                            "OANDA:SPX500USD|12M"
                        ],
                        [
                            "US100",
                            "CURRENCYCOM:US100|12M"
                        ],
                        [
                            "US Wall Street 30",
                            "OANDA:US30USD|12M"
                        ]
                    ],
                    chartOnly: false,
                    width: "100%",
                    height: "100%",
                    locale: "en",
                    colorTheme: "light",
                    backgroundColor: "#E5E0BD",
                    autosize: false,
                    showVolume: false,
                    hideDateRanges: false,
                    hideMarketStatus: false,
                    scalePosition: "right",
                    scaleMode: "Normal",
                    fontFamily: "-apple-system, BlinkMacSystemFont, Trebuchet MS, Roboto, Ubuntu, sans-serif",
                    fontSize: "10",
                    noTimeScale: false,
                    valuesTracking: "1",
                    chartType: "line",
                    container_id: "tradingview_6cee2"
                });
            }
        };
        onLoadScriptRef.current = createWidget;
        if (!tvScriptLoadingPromise) {
            tvScriptLoadingPromise = new Promise((resolve)=>{
                const script = document.createElement("script");
                script.id = "tradingview-widget-loading-script";
                script.src = "https://s3.tradingview.com/tv.js";
                script.type = "text/javascript";
                script.onload = ()=>resolve(()=>{
                        return;
                    });
                document.head.appendChild(script);
            });
        }
        tvScriptLoadingPromise.then(()=>onLoadScriptRef.current && onLoadScriptRef.current());
        return ()=>{
            onLoadScriptRef.current = null;
        };
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full h-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "tradingview-widget-container",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                id: "tradingview_6cee2"
            })
        })
    });
};
/* harmony default export */ const MarketPerformance_MarketPerformance = (MarketPerformance);

;// CONCATENATED MODULE: ./src/components/News/News.tsx


const News = ()=>{
    const container = (0,external_react_.useRef)(null);
    (0,external_react_.useEffect)(()=>{
        const script = document.createElement("script");
        script.src = "https://s3.tradingview.com/external-embedding/embed-widget-timeline.js";
        script.async = true;
        script.innerHTML = JSON.stringify({
            "feedMode": "all_symbols",
            "colorTheme": "light",
            "isTransparent": true,
            "displayMode": "regular",
            "width": "100%",
            "height": "100%",
            "locale": "en"
        });
        container.current.appendChild(script);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "tradingview-widget-container",
        ref: container,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "tradingview-widget-container__widget"
        })
    });
};
/* harmony default export */ const News_News = (News);

;// CONCATENATED MODULE: ./src/components/MarketOverview/MarketOverview.tsx




const MarketOverview = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-beige-300 mt-6 p-4 flex flex-col shadow-lg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(TickerBanner_TickerBanner, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full flex flex-row gap-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-2/3 min-h-[32rem] h-[32rem]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(MarketPerformance_MarketPerformance, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-1/3 min-h-[32rem] h-[32rem]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(News_News, {})
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const MarketOverview_MarketOverview = (MarketOverview);

;// CONCATENATED MODULE: ./src/components/Watchlist/WatchlistRow/WatchlistRow.tsx




const textClass = "font-raleway font-semibold text-xl";
const WatchlistRow = ({ index , ticker , company , lastPrice , change , percentageChange , marketCap , onRemove , header =false  })=>{
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `flex flex-row h-14 px-2 rounded-lg items-center ${index !== undefined && index % 2 !== 0 ? "bg-beige-300" : ""}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-row items-center gap-6 w-full",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: `w-[10%] ${textClass}`,
                    children: header ? "Symbol" : ticker
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: `w-[27%] ${textClass}`,
                    children: header ? "Company Name" : company
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: `w-[12%] ${textClass}`,
                    children: header ? "Last Price" : lastPrice
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: `w-[12%] ${textClass} ${change && (change > 0 ? "text-green-700" : "text-red-700")}`,
                    children: header ? "Change" : change?.toLocaleString("en-US")
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: `w-[12%] ${textClass} ${percentageChange && (percentageChange > 0 ? "text-green-700" : "text-red-700")}`,
                    children: header ? "% Change" : `${percentageChange?.toLocaleString("en-US")}%`
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: `w-[12%] ${textClass}`,
                    children: header ? " Market Cap" : marketCap ? (0,clientUtils/* nFormatter */.pF)(marketCap, 2) : ""
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `w-[15%]`,
                    children: header ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: `${textClass}`,
                        children: "Action"
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row gap-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "font-raleway text-md text-white bg-green-700 py-2 px-3 rounded-lg hover:scale-105",
                                onClick: ()=>router.push(`/simulator/${ticker}`),
                                children: "Trade"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "font-raleway text-md text-white bg-red-700 py-2 px-3 rounded-lg hover:scale-105",
                                onClick: ()=>onRemove && ticker && onRemove(ticker),
                                children: "Remove"
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const WatchlistRow_WatchlistRow = (WatchlistRow);

;// CONCATENATED MODULE: ./src/components/Watchlist/Watchlist.tsx





const Watchlist = ()=>{
    const [availability, setAvailability] = (0,external_react_.useState)(false);
    const [tickers, setTickers] = (0,external_react_.useState)([]);
    const removeTickerMutation = trpc/* trpc.watchlist.deleteFromWatchlist.useMutation */.S.watchlist.deleteFromWatchlist.useMutation({
        onSuccess: ()=>{
            multipleTickerQuery.refetch();
        }
    });
    const multipleTickerQuery = trpc/* trpc.watchlist.getWatchlist.useQuery */.S.watchlist.getWatchlist.useQuery(undefined, {
        onSuccess: (data)=>{
            setAvailability(true);
            setTickers(data);
        }
    });
    const handleDeleteFromWatchlist = async (ticker)=>{
        setTickers(tickers.filter((singleTicker)=>singleTicker.ticker !== ticker));
        removeTickerMutation.mutate({
            ticker
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: availability ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative flex flex-col",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(WatchlistRow_WatchlistRow, {
                    header: true
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: "border-slate-400 my-2"
                }),
                tickers.map((tickerInfo)=>/*#__PURE__*/ jsx_runtime_.jsx(WatchlistRow_WatchlistRow, {
                        index: tickerInfo.index,
                        ticker: tickerInfo.ticker,
                        company: tickerInfo.company,
                        lastPrice: tickerInfo.lastPrice,
                        change: tickerInfo.change,
                        percentageChange: tickerInfo.percentageChange,
                        marketCap: tickerInfo.marketCap,
                        onRemove: handleDeleteFromWatchlist
                    }, `key of row in watchlist for ${tickerInfo.ticker}`))
            ]
        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "mx-0 flex justify-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_spinners_.ClipLoader, {
                color: "#395144"
            })
        })
    });
};
/* harmony default export */ const Watchlist_Watchlist = (Watchlist);

;// CONCATENATED MODULE: ./src/components/TradeOptions/AccountInformation/AccountInformation.tsx



const AccountInformation = ({ name , value , helper =""  })=>{
    const [openHelper, setOpenHelper] = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row gap-2 items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "capitalize font-raleway text-xl text-green-700 font-semibold",
                        children: name
                    }),
                    helper && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center",
                        onMouseMove: ()=>setOpenHelper(true),
                        onMouseLeave: ()=>setOpenHelper(false),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillQuestionCircle, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative",
                                children: openHelper && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "absolute z-10 w-80 bg-beige-300 border rounded-lg p-2",
                                    children: helper
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "font-raleway text-xl",
                children: `$${value.toLocaleString("en-US")}`
            })
        ]
    });
};
/* harmony default export */ const AccountInformation_AccountInformation = (AccountInformation);

;// CONCATENATED MODULE: ./src/components/TradeOptions/TradeOptions.tsx









const errorMessage = {
    ZERO_QUANTITY: "Please enter a quantity larger than 0.",
    OVERSELL: "You may have entered a quantity larger than the number of chosen stock in your portfolio. Please try again.",
    OVERBUY: "You may not have enough cash in your account to make this transaction. Please try again.",
    MARKET_CLOSED: "The market is currently closed. Please try again later."
};
const AccountInfoHelper = {
    accountValue: "Displays the total current value of your portfolio.",
    buyingPower: "The total value of your cash and margin accounts that can be used to make trades.\nCalculated as: Cash + 50% (Long Stocks) - 150% (Shorted Stocks) (Investopedia)",
    cash: "Total amount of cash available for making trades."
};
const TradeOptions = ({ onPreview  })=>{
    // Route
    const router = (0,router_.useRouter)();
    const { ticker: tickerRoute  } = router.query;
    const ticker = tickerRoute;
    // Stores
    const { setMessage , setAppear  } = (0,store/* useError */.VI)();
    // States
    const [userCash, setUserCash] = (0,external_react_.useState)(0);
    const [openType, setOpenType] = (0,external_react_.useState)(false);
    const [sellAvailability, setSellAvailability] = (0,external_react_.useState)(0);
    const [holdingsValue, setHoldingsValue] = (0,external_react_.useState)(0);
    const [readyToTrade, setReadyToTrade] = (0,external_react_.useState)(false);
    const [transactionInfo, setTransactionInfo] = (0,external_react_.useState)({
        type: "buy",
        quantity: 0,
        bid: 0,
        ask: 0,
        marketState: ""
    });
    // Refs
    const quantityRef = (0,external_react_.useRef)(null);
    // Queries/Mutations
    trpc/* trpc.user.getUserInfo.useQuery */.S.user.getUserInfo.useQuery(undefined, {
        onSuccess: (data)=>{
            setUserCash(data.cash);
        }
    });
    trpc/* trpc.portfolio.getHoldings.useQuery */.S.portfolio.getHoldings.useQuery(undefined, {
        onSuccess: (data)=>{
            let totalHoldingsValue = 0;
            data.forEach((tickerRow)=>{
                if (tickerRow.currentPrice) totalHoldingsValue += tickerRow.quantity * tickerRow.currentPrice;
                if (tickerRow.ticker === ticker) setSellAvailability(tickerRow.quantity);
            });
            setHoldingsValue(totalHoldingsValue);
            setReadyToTrade(true);
        }
    });
    trpc/* trpc.ticker.getTickerInfo.useQuery */.S.ticker.getTickerInfo.useQuery({
        ticker
    }, {
        onSuccess: (data)=>{
            console.log(data.marketState);
            setTransactionInfo({
                ...transactionInfo,
                bid: data.bid,
                ask: data.ask,
                marketState: data.marketState
            });
        }
    });
    // Behaviors
    const setError = (code)=>{
        if (code === null) return;
        setMessage(errorMessage[code]);
        setAppear();
    };
    const handlePreview = ()=>{
        if (transactionInfo.marketState !== "REGULAR") {
            setError("MARKET_CLOSED");
        } else if (transactionInfo.quantity === 0) {
            setError("ZERO_QUANTITY");
        } else if (transactionInfo.type === "buy" && userCash < transactionInfo.quantity * transactionInfo.ask) {
            setError("OVERBUY");
        } else if (transactionInfo.type === "sell" && sellAvailability < transactionInfo.quantity) {
            setError("OVERSELL");
        } else {
            onPreview(transactionInfo);
        }
    };
    const setMaxQuant = ()=>{
        let maxQuant = 0;
        if (transactionInfo.type === "buy") {
            if (!transactionInfo.ask || transactionInfo.ask === 0) {
                maxQuant = 0;
            } else {
                maxQuant = Math.floor(userCash / transactionInfo.ask);
            }
        } else {
            maxQuant = Math.floor(sellAvailability);
        }
        setTransactionInfo({
            ...transactionInfo,
            quantity: maxQuant
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " mt-20 mb-10 flex flex-col gap-10",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-7/12 pr-6 flex flex-row gap justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-2/5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(AccountInformation_AccountInformation, {
                            name: "Account Value",
                            value: userCash + holdingsValue,
                            helper: AccountInfoHelper.accountValue
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-2/5 border-l border-r px-5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(AccountInformation_AccountInformation, {
                            name: "Buying Power",
                            value: userCash + holdingsValue / 2,
                            helper: AccountInfoHelper.accountValue
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-1/5 flex-col px-5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(AccountInformation_AccountInformation, {
                            name: "Cash",
                            value: userCash,
                            helper: AccountInfoHelper.accountValue
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col gap-12",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " flex flex-row",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "relative flex flex-col",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-raleway font-semibold text-xl text-green-700",
                                    children: "Action"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-row items-center gap-20",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "bg-transparent relative border border-solid rounded-md border-black h-14 font-normal font-raleway text-black w-80",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    className: "px-3 h-full w-full",
                                                    onClick: ()=>setOpenType(!openType),
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "float-left text-xl capitalize",
                                                            children: transactionInfo.type
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "float-right mt-2",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiArrowDownSLine, {})
                                                        })
                                                    ]
                                                }),
                                                openType && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "absolute z-10 top-14 w-full bg-beige-500 rounded-md flex flex-col",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            value: "buy",
                                                            className: "font-raleway text-xl capitalize p-3 text-left hover:bg-beige-600 rounded-md",
                                                            onClick: (e)=>{
                                                                const value = e.target.value;
                                                                if (value === "buy") setTransactionInfo({
                                                                    ...transactionInfo,
                                                                    type: value
                                                                });
                                                                setOpenType(false);
                                                            },
                                                            children: "buy"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            value: "sell",
                                                            className: "font-raleway text-xl capitalize p-3 text-left hover:bg-beige-600 rounded-md",
                                                            onClick: (e)=>{
                                                                const value = e.target.value;
                                                                if (value === "sell") setTransactionInfo({
                                                                    ...transactionInfo,
                                                                    type: value
                                                                });
                                                                setOpenType(false);
                                                            },
                                                            children: "sell"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "my-0",
                                            children: transactionInfo.marketState !== "REGULAR" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-row gap-1 items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiXCircle, {
                                                        style: {
                                                            color: "#941D1D",
                                                            height: "1.25rem",
                                                            width: "1.25rem"
                                                        }
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "font-raleway text-lg text-red-700",
                                                        children: "Market is closed"
                                                    })
                                                ]
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-row gap-1 items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiCheckCircle, {
                                                        style: {
                                                            color: "#395144",
                                                            height: "1.25rem",
                                                            width: "1.25rem"
                                                        }
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "font-raleway text-lg text-green-700",
                                                        children: "Market is open"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row gap-20",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                className: "flex flex-col w-80",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "float-left font-raleway font-semibold text-xl text-green-700",
                                                children: "Quantity"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                className: "float-right h-fit flex flex-row gap-1 items-center",
                                                onClick: setMaxQuant,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillEye, {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        children: "Show Max"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        ref: quantityRef,
                                        className: "text-2xl bg-transparent relative border border-solid rounded-md border-black h-14 font-normal font-raleway text-black px-3 ",
                                        type: "number",
                                        min: "0",
                                        value: transactionInfo.quantity !== 0 ? transactionInfo.quantity : "",
                                        pattern: "[0-9]*",
                                        onChange: (e)=>{
                                            setTransactionInfo({
                                                ...transactionInfo,
                                                quantity: +e.target.value
                                            });
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col w-80",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "font-raleway font-semibold text-xl text-green-700",
                                        children: "Est. Price"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "px-3 border border-solid rounded-md border-black h-14 flex items-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "font-raleway text-black text-2xl",
                                            children: transactionInfo.marketState !== "REGULAR" ? "" : transactionInfo.type === "buy" ? transactionInfo.ask : transactionInfo.bid
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col w-80",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "font-raleway font-semibold text-xl text-green-700",
                                        children: "Total Value"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "px-3 border border-solid rounded-md border-black h-14 flex items-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "font-raleway text-black text-2xl",
                                            children: transactionInfo.marketState !== "REGULAR" ? "" : (transactionInfo.quantity * (transactionInfo.type === "buy" ? transactionInfo.ask : transactionInfo.bid)).toLocaleString("en-US")
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "pr-4 mt-4 flex flex-row gap-10 justify-start w-7/12",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: `py-4 w-1/2 rounded-lg font-raleway text-xl text-white bg-red-700 hover:scale-105`,
                        onClick: ()=>{
                            setTransactionInfo({
                                ...transactionInfo,
                                type: "buy",
                                quantity: 0
                            });
                        },
                        children: "Clear Order"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: `py-4 w-1/2 rounded-lg font-raleway text-xl text-white ${readyToTrade ? "bg-green-700 hover:scale-105" : "pointer-events-none bg-beige-700"}`,
                        onClick: handlePreview,
                        children: readyToTrade ? "Preview Order" : "Loading Details..."
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const TradeOptions_TradeOptions = (TradeOptions);

;// CONCATENATED MODULE: ./src/components/CompanyProfile/CompanyProfile.tsx




const CompanyProfile = ()=>{
    // Route
    const router = (0,router_.useRouter)();
    const { ticker: tickerRoute  } = router.query;
    const ticker = tickerRoute;
    const tickerInfoQuery = trpc/* trpc.ticker.getTickerInfo.useQuery */.S.ticker.getTickerInfo.useQuery({
        ticker
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-7/12 pr-6 mt-20 mb-10 flex flex-col gap-10",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col gap-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "capitalize font-raleway text-3xl text-green-700 font-semibold",
                        children: "Company Name"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                        className: "h border-slate-500"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-raleway text-xl",
                        children: tickerInfoQuery.data?.name
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col gap-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "capitalize font-raleway text-3xl text-green-700 font-semibold",
                        children: "Sector"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                        className: "h border-slate-500"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-raleway text-xl",
                        children: tickerInfoQuery.data?.sector
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col gap-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "capitalize font-raleway text-3xl text-green-700 font-semibold",
                        children: "Industry"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                        className: "h border-slate-500"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-raleway text-xl",
                        children: tickerInfoQuery.data?.industry
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col gap-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "capitalize font-raleway text-3xl text-green-700 font-semibold",
                        children: "Employees"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                        className: "h border-slate-500"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-raleway text-xl",
                        children: tickerInfoQuery.data?.employees?.toLocaleString("en-US")
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col gap-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "capitalize font-raleway text-3xl text-green-700 font-semibold",
                        children: "Business Summary"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                        className: "h border-slate-500"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-raleway text-xl",
                        children: tickerInfoQuery.data?.summary
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const CompanyProfile_CompanyProfile = (CompanyProfile);

;// CONCATENATED MODULE: ./src/components/index.ts



















const PortfolioPerformanceChart = dynamic_default()(()=>__webpack_require__.e(/* import() */ 104).then(__webpack_require__.bind(__webpack_require__, 3104)), {
    loadableGenerated: {
        modules: [
            "..\\components\\index.ts -> " + "./PortfolioPerformanceChart/PortfolioPerformanceChart"
        ]
    },
    ssr: false
});









/***/ }),

/***/ 8879:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Dw": () => (/* binding */ popupClass),
/* harmony export */   "QU": () => (/* binding */ reverseFormatScreener),
/* harmony export */   "Ww": () => (/* binding */ pageTitleClass),
/* harmony export */   "kc": () => (/* binding */ portfolioHelperMessages),
/* harmony export */   "pF": () => (/* binding */ nFormatter),
/* harmony export */   "yx": () => (/* binding */ formatScreener)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2166);

const popupClass = "fixed left-[41.87%] right-[19.37%] z-10 min-h-fit min-w-fit px-6 py-10 flex flex-col";
const pageTitleClass = "text-center font-raleway text-5xl text-green-700 font-semibold uppercase";
const portfolioHelperMessages = {
    accountValue: "Displays the total current value of your portfolio.",
    buyingPower: "The total value of your cash and margin accounts that can be used to make trades.\nCalculated as: Cash + 50% (Long Stocks) - 150% (Shorted Stocks) (Investopedia)",
    cash: "Total amount of cash available for making trades.",
    annualReturn: "Percentage of return that you have earned if your returns were extrapolated for a year.",
    cummulativeReturn: "The total change in the investment price over a set time—an aggregate return, not an annualized one"
};
const nFormatter = (num, digits)=>{
    const lookup = [
        {
            value: 1,
            symbol: ""
        },
        {
            value: 1e3,
            symbol: "k"
        },
        {
            value: 1e6,
            symbol: "M"
        },
        {
            value: 1e9,
            symbol: "G"
        },
        {
            value: 1e12,
            symbol: "T"
        },
        {
            value: 1e15,
            symbol: "P"
        },
        {
            value: 1e18,
            symbol: "E"
        }
    ];
    const rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
    const item = lookup.slice().reverse().find(function(item) {
        return num >= item.value;
    });
    return item ? (num / item.value).toFixed(digits).replace(rx, "$1") + item.symbol : "0";
};
const formatScreener = (value)=>{
    const retVal = structuredClone(value);
    if (retVal.marketCap.min === _constants__WEBPACK_IMPORTED_MODULE_0__/* .screenerConstants.marketCap.min */ .aq.marketCap.min - 1) {
        retVal.marketCap.min = null;
    }
    if (retVal.marketCap.max === _constants__WEBPACK_IMPORTED_MODULE_0__/* .screenerConstants.marketCap.max */ .aq.marketCap.max + 1) {
        retVal.marketCap.max = null;
    }
    if (retVal.avgVolume.min === _constants__WEBPACK_IMPORTED_MODULE_0__/* .screenerConstants.avgVolume.min */ .aq.avgVolume.min - 1) {
        retVal.avgVolume.min = null;
    }
    if (retVal.avgVolume.max === _constants__WEBPACK_IMPORTED_MODULE_0__/* .screenerConstants.avgVolume.max */ .aq.avgVolume.max + 1) {
        retVal.avgVolume.max = null;
    }
    return retVal;
};
const reverseFormatScreener = (value)=>{
    const retVal = structuredClone(value);
    if (retVal.marketCap.min == null) {
        retVal.marketCap.min = _constants__WEBPACK_IMPORTED_MODULE_0__/* .screenerConstants.marketCap.min */ .aq.marketCap.min - 1;
    }
    if (retVal.marketCap.max == null) {
        retVal.marketCap.max = _constants__WEBPACK_IMPORTED_MODULE_0__/* .screenerConstants.marketCap.max */ .aq.marketCap.max + 1;
    }
    if (retVal.avgVolume.min == null) {
        retVal.avgVolume.min = _constants__WEBPACK_IMPORTED_MODULE_0__/* .screenerConstants.avgVolume.min */ .aq.avgVolume.min - 1;
    }
    if (retVal.avgVolume.max == null) {
        retVal.avgVolume.max = _constants__WEBPACK_IMPORTED_MODULE_0__/* .screenerConstants.avgVolume.max */ .aq.avgVolume.max + 1;
    }
    return retVal;
};


/***/ })

};
;