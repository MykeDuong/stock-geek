"use strict";
exports.id = 104;
exports.ids = [104];
exports.modules = {

/***/ 3104:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lightweight_charts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6247);
/* harmony import */ var lightweight_charts__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lightweight_charts__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_trpc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4097);




const colors = {
    backgroundColor: "transparent",
    lineColor: "#395144",
    SPLineColor: "#941D1D",
    textColor: "black",
    areaTopColor: "transparent",
    areaBottomColor: "transparent"
};
const PortfolioPerformanceChart = ()=>{
    // States
    const [portfolioData, setPortfolioData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [SPFiveHundredData, setSPFiveHundredData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [portfolioAvailable, setPortfolioAvailable] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [dataAvailable, setDataAvailable] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    // Queries/Mutations
    const SPFiveHundredQuery = _utils_trpc__WEBPACK_IMPORTED_MODULE_3__/* .trpc.ticker.getSPFiveHundred.useQuery */ .S.ticker.getSPFiveHundred.useQuery({
        startingPoint: portfolioData[0] ? portfolioData[0].time : new Date()
    }, {
        enabled: portfolioAvailable,
        onSuccess: (data)=>{
            setSPFiveHundredData(data);
        }
    });
    _utils_trpc__WEBPACK_IMPORTED_MODULE_3__/* .trpc.portfolio.getTimeSeriesValues.useQuery */ .S.portfolio.getTimeSeriesValues.useQuery(undefined, {
        onSuccess: (data)=>{
            setPortfolioData(data.map((row)=>({
                    time: row.date,
                    value: row.value
                })));
        }
    });
    const container = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (portfolioData.length === 0) return;
        setPortfolioAvailable(true);
    }, [
        portfolioData
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (SPFiveHundredData.length === 0) return;
        setDataAvailable(true);
    }, [
        SPFiveHundredData
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!container.current || !dataAvailable) return;
        const chart = (0,lightweight_charts__WEBPACK_IMPORTED_MODULE_2__.createChart)(container.current, {
            layout: {
                background: {
                    type: lightweight_charts__WEBPACK_IMPORTED_MODULE_2__.ColorType.Solid,
                    color: colors.backgroundColor
                },
                textColor: colors.textColor
            },
            rightPriceScale: {
                scaleMargins: {
                    top: 0.3,
                    bottom: 0.25
                }
            },
            crosshair: {
                // hide the horizontal crosshair line
                horzLine: {
                    visible: false,
                    labelVisible: false
                }
            },
            // hide the grid lines
            grid: {
                vertLines: {
                    visible: false
                },
                horzLines: {
                    visible: false
                }
            },
            width: container.current.clientWidth,
            height: container.current.clientHeight
        });
        chart.timeScale().fitContent();
        const portfolioSeries = chart.addAreaSeries({
            lineColor: colors.lineColor,
            topColor: colors.areaTopColor,
            bottomColor: colors.areaBottomColor
        });
        portfolioSeries.setData(portfolioData.map((row)=>{
            return {
                ...row,
                time: row.time.toLocaleDateString("en-US", {
                    timeZone: "America/New_York"
                })
            };
        }));
        const SPSeries = chart.addAreaSeries({
            lineColor: colors.SPLineColor,
            topColor: colors.areaTopColor,
            bottomColor: colors.areaBottomColor
        });
        SPSeries.setData(SPFiveHundredData.map((row)=>{
            return {
                value: row.value / SPFiveHundredData[0].value * 10000,
                time: row.time.toLocaleDateString("en-US", {
                    timeZone: "America/New_York"
                })
            };
        }));
        const handleResize = ()=>{
            if (!container.current) return;
            chart.applyOptions({
                width: container.current.clientWidth,
                height: container.current.clientHeight
            });
        };
        const portfolioLegend = "Portfolio Performance:";
        const SPLegend = "S&P 500 Performance:";
        const legend = document.createElement("div");
        legend.className = `absolute left-[12px] top-[12px] z-10 text-lg font-raleway`;
        container.current.appendChild(legend);
        const firstRow = document.createElement("div");
        firstRow.innerHTML = portfolioLegend;
        firstRow.className = "text-green-700";
        legend.appendChild(firstRow);
        const secondRow = document.createElement("div");
        secondRow.innerHTML = SPLegend;
        secondRow.className = "text-red-700";
        legend.appendChild(secondRow);
        chart.subscribeCrosshairMove((param)=>{
            let portfolioValueFormatted = "";
            let SPValueFormatted = "";
            if (param.time) {
                const portfolioValue = param.seriesPrices.get(portfolioSeries);
                portfolioValueFormatted = portfolioValue?.toFixed(2);
                const SPValue = param.seriesPrices.get(SPSeries);
                SPValueFormatted = SPValue?.toFixed(2);
            }
            // legend is a html element which has already been created
            firstRow.innerHTML = `${portfolioLegend} <strong>${portfolioValueFormatted}</strong>`;
            secondRow.innerHTML = `${SPLegend} <strong>${SPValueFormatted}</strong>`;
        });
        window.addEventListener("resize", handleResize);
        return ()=>{
            window.removeEventListener("resize", handleResize);
            chart.remove();
        };
    }, [
        dataAvailable
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "h-full w-full relative",
        ref: container
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PortfolioPerformanceChart);


/***/ })

};
;