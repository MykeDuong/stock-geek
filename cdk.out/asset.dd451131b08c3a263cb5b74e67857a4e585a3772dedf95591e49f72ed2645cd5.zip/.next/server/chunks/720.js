"use strict";
exports.id = 720;
exports.ids = [720];
exports.modules = {

/***/ 7720:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "authOptions": () => (/* binding */ authOptions),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7449);
/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_pg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2918);
/* harmony import */ var _utils_authUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8272);
/* harmony import */ var _trpc_server__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2756);
/* harmony import */ var _trpc_server__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_trpc_server__WEBPACK_IMPORTED_MODULE_4__);





const authOptions = {
    // Include user.id on session
    callbacks: {
        jwt: async ({ token , user  })=>{
            if (user) token.user = user;
            return token;
        },
        session: async ({ session , token  })=>{
            if (token.user) {
                session.user = token.user;
            }
            return session;
        }
    },
    session: {
        strategy: "jwt"
    },
    providers: [
        next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1___default()({
            credentials: {
                usernameOrEmail: {
                    type: "text"
                },
                password: {
                    type: "password"
                }
            },
            async authorize (credentials, req) {
                if (!credentials) throw {
                    message: "credentials not found"
                };
                const { usernameOrEmail , password  } = credentials;
                let user;
                try {
                    const result = await (0,_utils_pg__WEBPACK_IMPORTED_MODULE_2__/* .findUser */ .oe)(usernameOrEmail);
                    user = {
                        id: result.user_id,
                        name: result.username,
                        email: result.email,
                        password: result.password
                    };
                    const match = (0,_utils_authUtils__WEBPACK_IMPORTED_MODULE_3__/* .comparePassword */ .O)(password, user.password);
                    if (!match) throw {
                        message: "Password mismatch"
                    };
                } catch (err) {
                    let message = "Unknown error";
                    if (err instanceof Error) {
                        message = err.message;
                    }
                    throw new _trpc_server__WEBPACK_IMPORTED_MODULE_4__.TRPCError({
                        code: "UNAUTHORIZED",
                        message
                    });
                }
                return user;
            }
        })
    ],
    secret: process.env.NEXTAUTH_SECRET,
    pages: {
        signIn: "/auth/",
        signOut: "/auth/",
        error: "/auth/error",
        newUser: "/auth"
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_auth__WEBPACK_IMPORTED_MODULE_0___default()(authOptions));


/***/ }),

/***/ 8272:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ comparePassword),
/* harmony export */   "c": () => (/* binding */ hashPassword)
/* harmony export */ });
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7096);
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_0__);

const saltRounds = 10;
const hashPassword = async (password)=>{
    const hashedPassword = await bcrypt__WEBPACK_IMPORTED_MODULE_0___default().hash(password, saltRounds).then((result)=>{
        return result;
    });
    return hashedPassword;
};
const comparePassword = async (password, dbPassword)=>{
    const match = await bcrypt__WEBPACK_IMPORTED_MODULE_0___default().compare(password, dbPassword);
    return match;
};


/***/ }),

/***/ 2918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "FW": () => (/* binding */ pg_addToWatchlist),
  "r4": () => (/* binding */ createUser),
  "dF": () => (/* binding */ pg_deleteFromWatchlist),
  "_J": () => (/* binding */ deleteScreener),
  "oe": () => (/* binding */ findUser),
  "tj": () => (/* binding */ findUserById),
  "s1": () => (/* binding */ getHistory),
  "LQ": () => (/* binding */ getHoldings),
  "zS": () => (/* binding */ getHoldingsByTicker),
  "xp": () => (/* binding */ getPortfolio),
  "h0": () => (/* binding */ pg_getScreenerById),
  "uT": () => (/* binding */ getWatchlist),
  "ym": () => (/* binding */ makeTransaction),
  "ld": () => (/* binding */ pg_saveScreener),
  "o9": () => (/* binding */ pg_updatePortfolio),
  "AA": () => (/* binding */ viewScreeners)
});

// UNUSED EXPORTS: default, findInWatchlist

// EXTERNAL MODULE: external "pg"
var external_pg_ = __webpack_require__(5900);
;// CONCATENATED MODULE: ./src/utils/sql.ts
// USERS
const createUserQuery = `
  INSERT INTO users (
    username,
    email, 
    password
  ) 
  VALUES (
    $1,	
    $2,	
    $3
  ) 
  RETURNING *
`;
const findUserQuery = `
  SELECT * FROM users 
  WHERE ($1 = username OR $1 = email)
`;
const findUserByIdQuery = `
  SELECT * FROM users 
  WHERE ($1 = user_id)
`;
// SCREENER
const saveScreener = `
  INSERT INTO screener (
    user_id,
    screener_name,
    market_cap_max,
    market_cap_min,
    volume_min,
    volume_max,
    pe_min,
    pe_max,
    de_min,
    de_max,
    beta_min,
    beta_max,
    price_min,
    price_max)
  VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
`;
const getScreeners = `
  SELECT screener_id,screener_name,create_time FROM screener
  WHERE user_id = $1
  ORDER BY create_time
`;
const getScreenerById = `
  SELECT * FROM screener
  WHERE screener_id = $1
`;
const deleteScreenerById = `
  DELETE FROM screener
  WHERE screener_id = $1
`;
// WATCHLIST
const addToWatchlist = `
  INSERT INTO watchlist(
    user_id,
    ticker
  )
  VALUES (
    $1,
    upper($2)
  )
`;
const deleteFromWatchlist = `
  DELETE FROM watchlist
  WHERE (user_id = $1 AND ticker ILIKE $2)
`;
const findInWatchlist = `
  SELECT * FROM watchlist
	WHERE user_id = $1 AND ticker = $2
`;
const viewWatchlist = `
  SELECT * FROM watchlist
  WHERE user_id = $1
`;
// TRANSACTIONS - TRADE HISTORY
const viewTransactions = `
  SELECT *, (quantity*stock_price) AS Total_Value FROM transactions
  WHERE user_id = $1
  ORDER BY date
`;
// HOLDINGS
const viewHoldingsByTicker = `
  SELECT SUM(quantity) AS quantity FROM holdings
  WHERE user_id = $1 AND ticker = upper($2)
`;
const viewHoldings = `
  SELECT ticker, SUM(quantity) AS quantity, SUM(price*quantity)/SUM(quantity) AS purchase_price FROM holdings
  WHERE user_id=$1
  GROUP BY ticker
`;
// PORTFOLIO
const viewPortfolio = `
  SELECT * FROM portfolio
  WHERE user_id = $1 
  ORDER BY date 
`;
const updatePortfolio = `
  INSERT INTO portfolio (user_id,date,value)
  VALUES ($1, (CURRENT_TIMESTAMP AT TIME ZONE 'America/New_York')::DATE, $2)
  ON CONFLICT (user_id, date)
  DO 
  UPDATE SET value = $2
  RETURNING *;
`;
// TRANSACTIONS
const addNewTransaction = `
  INSERT INTO transactions (user_id,ticker,transaction_type,stock_price,quantity)
  VALUES ($1,UPPER($2),$3,$4,$5)
`;

;// CONCATENATED MODULE: ./src/utils/pg.ts


const config = {
    connectionString: `postgres://${process.env.DB_USER}:${process.env.DB_PASSWORD}@${process.env.DB_HOST}:${process.env.DB_PORT}/${process.env.DB_DATABASE}?options`
};
const pool = new external_pg_.Pool(config);
/* harmony default export */ const pg = ((/* unused pure expression or super */ null && (pool)));
// User
const createUser = async (username, email, password)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(createUserQuery, [
        username,
        email,
        password
    ]).then((res)=>{
        return res.rows[0];
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const findUser = async (usernameOrEmail)=>{
    console.assert(pool.totalCount === 0);
    console.assert(pool.idleCount === 0);
    let success = true;
    const client = await pool.connect();
    const result = await client.query(findUserQuery, [
        usernameOrEmail
    ]).then((res)=>{
        return res.rows[0];
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const findUserById = async (id)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(findUserByIdQuery, [
        id
    ]).then((res)=>{
        return res.rows[0];
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const pg_saveScreener = async (inputQuery)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(saveScreener, [
        inputQuery.userId,
        inputQuery.name,
        inputQuery.marketCapMax,
        inputQuery.marketCapMin,
        inputQuery.volumeMin,
        inputQuery.volumeMax,
        inputQuery.peMin,
        inputQuery.peMax,
        inputQuery.deMin,
        inputQuery.deMax,
        inputQuery.betaMin,
        inputQuery.betaMax,
        inputQuery.priceMin,
        inputQuery.priceMax
    ]).then((res)=>{
        return res;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const viewScreeners = async (userId)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(getScreeners, [
        userId
    ]).then((res)=>{
        return res.rows;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const pg_getScreenerById = async (id)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(getScreenerById, [
        id
    ]).then((res)=>{
        const result = res.rows[0];
        if (typeof result.market_cap_max === "string") {
            result.market_cap_max = parseInt(result.market_cap_max);
        }
        if (typeof result.market_cap_min === "string") {
            result.market_cap_min = parseInt(result.market_cap_min);
        }
        if (typeof result.volume_max === "string") {
            result.volume_max = parseInt(result.volume_max);
        }
        if (typeof result.volume_min === "string") {
            result.volume_min = parseInt(result.volume_min);
        }
        return result;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const deleteScreener = async (id)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(deleteScreenerById, [
        id
    ]).then((res)=>{
        return res;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
// Watchlist
const pg_findInWatchlist = async (userId, ticker)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(findInWatchlist, [
        userId,
        ticker
    ]).then((res)=>{
        return res;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const getWatchlist = async (userId)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(viewWatchlist, [
        userId
    ]).then((res)=>{
        return res.rows;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const pg_addToWatchlist = async (userId, ticker)=>{
    let success = true;
    const client = await pool.connect();
    try {
        const existed = await pg_findInWatchlist(userId, ticker);
        if (existed.rows.length !== 0) {
            throw Error("Watchlisted ");
        }
    } catch (err) {
        throw err;
    }
    const result = await client.query(addToWatchlist, [
        userId,
        ticker
    ]).then((res)=>{
        return res.rows[0];
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const pg_deleteFromWatchlist = async (userId, ticker)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(deleteFromWatchlist, [
        userId,
        ticker
    ]).then((res)=>{
        return res.rows;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const getHistory = async (userId)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(viewTransactions, [
        userId
    ]).then((res)=>{
        return res.rows;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const makeTransaction = async (userId, ticker, type, price, quantity)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(addNewTransaction, [
        userId,
        ticker,
        type,
        price,
        quantity
    ]).then((res)=>{
        return res;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
// Holdings
const getHoldingsByTicker = async (userId, ticker)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(viewHoldingsByTicker, [
        userId,
        ticker
    ]).then((res)=>{
        if (res.rows[0].quantity) {
            return parseInt(res.rows[0].quantity);
        }
        return 0;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const getHoldings = async (userId)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(viewHoldings, [
        userId
    ]).then((res)=>{
        return res.rows;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
// Portfolio
const getPortfolio = async (userId)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(viewPortfolio, [
        userId
    ]).then((res)=>{
        return res.rows;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};
const pg_updatePortfolio = async (userId, value)=>{
    let success = true;
    const client = await pool.connect();
    const result = await client.query(updatePortfolio, [
        userId,
        value
    ]).then((res)=>{
        return res.rows;
    }).catch((e)=>{
        success = false;
        return e;
    });
    client.release(true);
    if (success) return result;
    else throw result;
};


/***/ })

};
;