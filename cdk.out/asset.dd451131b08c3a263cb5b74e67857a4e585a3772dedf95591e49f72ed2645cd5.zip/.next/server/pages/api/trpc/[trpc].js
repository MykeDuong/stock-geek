"use strict";
(() => {
var exports = {};
exports.id = 829;
exports.ids = [829,748];
exports.modules = {

/***/ 2756:
/***/ ((module) => {

module.exports = require("@trpc/server");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 5900:
/***/ ((module) => {

module.exports = require("pg");

/***/ }),

/***/ 9374:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _trpc_)
});

;// CONCATENATED MODULE: external "@trpc/server/adapters/next"
const next_namespaceObject = require("@trpc/server/adapters/next");
;// CONCATENATED MODULE: external "zod"
const external_zod_namespaceObject = require("zod");
;// CONCATENATED MODULE: ./src/env/schema.mjs
// @ts-check

/**
 * Specify your server-side environment variables schema here.
 * This way you can ensure the app isn't built with invalid env vars.
 */ const serverSchema = external_zod_namespaceObject.z.object({
    NODE_ENV: external_zod_namespaceObject.z["enum"]([
        "development",
        "test",
        "production"
    ]),
    NEXTAUTH_URL: external_zod_namespaceObject.z.preprocess(// This makes Vercel deployments not fail if you don't set NEXTAUTH_URL
    // Since NextAuth.js automatically uses the VERCEL_URL if present.
    (str)=>process.env.VERCEL_URL ?? str, // VERCEL_URL doesn't include `https` so it cant be validated as a URL
    process.env.VERCEL ? external_zod_namespaceObject.z.string() : external_zod_namespaceObject.z.string().url()),
    // Database
    DB_HOST: external_zod_namespaceObject.z.string(),
    DB_PORT: external_zod_namespaceObject.z.string().min(1).max(5),
    DB_USER: external_zod_namespaceObject.z.string(),
    DB_PASSWORD: external_zod_namespaceObject.z.string(),
    DB_DATABASE: external_zod_namespaceObject.z.string().min(1),
    // RAPID API
    API_HOST: external_zod_namespaceObject.z.string(),
    API_KEY: external_zod_namespaceObject.z.string()
});
/**
 * Specify your client-side environment variables schema here.
 * This way you can ensure the app isn't built with invalid env vars.
 * To expose them to the client, prefix them with `NEXT_PUBLIC_`.
 */ const clientSchema = external_zod_namespaceObject.z.object({
});
/**
 * You can't destruct `process.env` as a regular object, so you have to do
 * it manually here. This is because Next.js evaluates this at build time,
 * and only used environment variables are included in the build.
 * @type {{ [k in keyof z.infer<typeof clientSchema>]: z.infer<typeof clientSchema>[k] | undefined }}
 */ const clientEnv = {
};

;// CONCATENATED MODULE: ./src/env/client.mjs
// @ts-check

const _clientEnv = clientSchema.safeParse(clientEnv);
const formatErrors = (/** @type {import('zod').ZodFormattedError<Map<string,string>,string>} */ errors)=>Object.entries(errors).map(([name, value])=>{
        if (value && "_errors" in value) return `${name}: ${value._errors.join(", ")}\n`;
    }).filter(Boolean);
if (!_clientEnv.success) {
    console.error("❌ Invalid environment variables:\n", ...formatErrors(_clientEnv.error.format()));
    throw new Error("Invalid environment variables");
}
for (let key of Object.keys(_clientEnv.data)){
    if (!key.startsWith("NEXT_PUBLIC_")) {
        console.warn(`❌ Invalid public environment variable name: ${key}. It must begin with 'NEXT_PUBLIC_'`);
        throw new Error("Invalid public environment variable name");
    }
}
const env = _clientEnv.data;

;// CONCATENATED MODULE: ./src/env/server.mjs
// @ts-check
/**
 * This file is included in `/next.config.mjs` which ensures the app isn't built with invalid env vars.
 * It has to be a `.mjs`-file to be imported there.
 */ 

const _serverEnv = serverSchema.safeParse(process.env);
if (!_serverEnv.success) {
    console.error("❌ Invalid environment variables:\n", ...formatErrors(_serverEnv.error.format()));
    throw new Error("Invalid environment variables");
}
for (let key of Object.keys(_serverEnv.data)){
    if (key.startsWith("NEXT_PUBLIC_")) {
        console.warn("❌ You are exposing a server-side env-variable:", key);
        throw new Error("You are exposing a server-side env-variable");
    }
}
const server_env = {
    ..._serverEnv.data,
    ...env
};

// EXTERNAL MODULE: ./src/server/common/get-server-auth-session.ts
var get_server_auth_session = __webpack_require__(2399);
;// CONCATENATED MODULE: ./src/server/trpc/context.ts

/** Use this helper for:
 * - testing, so we dont have to mock Next.js' req/res
 * - trpc's `createSSGHelpers` where we don't have req/res
 * @see https://create.t3.gg/en/usage/trpc#-servertrpccontextts
 **/ const createContextInner = async (opts)=>{
    return {
        session: opts.session
    };
};
/**
 * This is the actual context you'll use in your router
 * @link https://trpc.io/docs/context
 **/ const createContext = async (opts)=>{
    const { req , res  } = opts;
    // Get the session from the server using the unstable_getServerSession wrapper function
    const session = await (0,get_server_auth_session/* getServerAuthSession */.W)({
        req,
        res
    });
    return await createContextInner({
        session
    });
};

// EXTERNAL MODULE: external "@trpc/server"
var server_ = __webpack_require__(2756);
;// CONCATENATED MODULE: external "superjson"
const external_superjson_namespaceObject = require("superjson");
var external_superjson_default = /*#__PURE__*/__webpack_require__.n(external_superjson_namespaceObject);
;// CONCATENATED MODULE: ./src/server/trpc/trpc.ts


const t = server_.initTRPC.context().create({
    transformer: (external_superjson_default()),
    errorFormatter ({ shape  }) {
        return shape;
    }
});
const router = t.router;
/**
 * Unprotected procedure
 **/ const publicProcedure = t.procedure;
/**
 * Reusable middleware to ensure
 * users are logged in
 */ const isAuthed = t.middleware(({ ctx , next  })=>{
    if (!ctx.session || !ctx.session.user) {
        throw new server_.TRPCError({
            code: "UNAUTHORIZED"
        });
    }
    return next({
        ctx: {
            // infers the `session` as non-nullable
            session: {
                ...ctx.session,
                user: ctx.session.user
            }
        }
    });
});
/**
 * Protected procedure
 **/ const protectedProcedure = t.procedure.use(isAuthed);

// EXTERNAL MODULE: ./src/utils/authUtils.ts
var authUtils = __webpack_require__(8272);
// EXTERNAL MODULE: ./src/utils/pg.ts + 1 modules
var pg = __webpack_require__(2918);
;// CONCATENATED MODULE: ./src/server/trpc/router/auth.ts





const authRouter = router({
    getSession: publicProcedure.query(({ ctx  })=>{
        return ctx.session;
    }),
    signup: publicProcedure.input(external_zod_namespaceObject.z.object({
        username: external_zod_namespaceObject.z.string().min(1).max(20),
        email: external_zod_namespaceObject.z.string().min(1).email("Must be a valid email address"),
        password: external_zod_namespaceObject.z.string().min(5)
    })).mutation(async ({ input  })=>{
        const { username , email , password  } = input;
        const hashedPassword = await (0,authUtils/* hashPassword */.c)(password);
        let user;
        try {
            user = await (0,pg/* createUser */.r4)(username, email, hashedPassword);
        } catch (err) {
            const message = "Sorry, your email or username has already been used";
            throw new server_.TRPCError({
                code: "UNAUTHORIZED",
                message
            });
        }
        return {
            user,
            status: 200,
            msg: "success"
        };
    })
});

;// CONCATENATED MODULE: ./src/utils/serverUtils.ts
const defaultError = {
    code: "INTERNAL_SERVER_ERROR",
    message: "An error has occurred. Please try again later.",
    name: "Default Error"
};

;// CONCATENATED MODULE: external "yahoo-finance2"
const external_yahoo_finance2_namespaceObject = require("yahoo-finance2");
var external_yahoo_finance2_default = /*#__PURE__*/__webpack_require__.n(external_yahoo_finance2_namespaceObject);
;// CONCATENATED MODULE: ./src/utils/yahooFinance.ts

external_yahoo_finance2_default().setGlobalConfig({
    validation: {
        logErrors: false
    }
});
function isYHError(value) {
    return !!value && !!value.result && !!value.errors;
}
const headers = {
    "X-RapidAPI-Key": process.env.API_KEY,
    "X-RapidAPI-Host": process.env.API_HOST
};
const getTrending = async ()=>{
    const queryOptions = {
        count: 50,
        lang: "en-US"
    };
    const { quotes  } = await external_yahoo_finance2_default().trendingSymbols("US", queryOptions);
    const symbols = quotes.map((quote)=>quote.symbol);
    if (symbols.length === 0) return [];
    try {
        const result = await external_yahoo_finance2_default().quote(symbols);
        return result.filter((quote)=>{
            if (quote.quoteType !== "EQUITY") return false;
            if (quote.fullExchangeName.includes("Nasdaq")) return true;
            if (quote.fullExchangeName.includes("NYSE")) return true;
            return false;
        });
    } catch (err) {
        if (isYHError(err)) {
            const result1 = err.result.filter((quote)=>{
                if (quote.quoteType !== "EQUITY") return false;
                if (quote.fullExchangeName.includes("Nasdaq")) return true;
                if (quote.fullExchangeName.includes("NYSE")) return true;
                return false;
            });
            return result1;
        }
    }
};
const getRecommendations = async (searchTickers)=>{
    const queryResult = await external_yahoo_finance2_default().recommendationsBySymbol(searchTickers);
    const duplicableResult = queryResult.map((recommendation)=>{
        return recommendation.recommendedSymbols;
    }).flat(1).map((ticker)=>ticker.symbol);
    const result = duplicableResult.filter((ticker, index)=>{
        return duplicableResult.indexOf(ticker) === index;
    });
    return shuffleArray(result);
};
const getQuoteList = async ()=>{
    return sampleResponse.quoteList;
};
const search = async (searchText)=>{
    const queryOptions = {
        region: "US",
        lang: "en-US"
    };
    const { quotes  } = await external_yahoo_finance2_default().search(searchText, queryOptions);
    const result = quotes.filter((quote)=>quote.quoteType === "EQUITY").filter((quote)=>quote.exchDisp === "NASDAQ" || quote.exchDisp === "NYSE").map((quote)=>({
            symbol: quote.symbol,
            name: quote.shortname
        }));
    return result;
};
const getTickerInfo = async (ticker)=>{
    const queryOptions = {
        modules: [
            "price",
            "summaryDetail",
            "assetProfile"
        ]
    };
    const result = await external_yahoo_finance2_default().quoteSummary(ticker, queryOptions);
    return result;
};
const getMultipleTickers = async (tickers)=>{
    const result = await external_yahoo_finance2_default().quote(tickers);
    return result;
};
const getMultipleTickersAsObjects = async (tickers)=>{
    try {
        const result = await external_yahoo_finance2_default().quote(tickers, {
            return: "object"
        });
        return result;
    } catch (err) {
        return {};
    }
};
const getSPFiveHundred = async (startingPoint)=>{
    try {
        const date = new Date();
        const result = await external_yahoo_finance2_default().historical("^GSPC", {
            period1: new Date(startingPoint),
            period2: date.setDate(date.getDate() - 1)
        });
        return result;
    } catch (err) {
        if (isYHError(err)) return err.result;
        return [];
    }
};
const shuffleArray = (array)=>{
    let currentIndex = array.length, randomIndex;
    // While there remain elements to shuffle.
    while(currentIndex != 0){
        // Pick a remaining element.
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;
        // And swap it with the current element.
        [array[currentIndex], array[randomIndex]] = [
            array[randomIndex],
            array[currentIndex]
        ];
    }
    return array;
};
const sampleResponse = {
    quoteList: [
        "AAPL",
        "GOOG",
        "AMD",
        "IBM",
        "META"
    ]
};

;// CONCATENATED MODULE: ./src/server/trpc/router/portfolio.ts





const portfolioRouter = router({
    getAvailability: protectedProcedure.input(external_zod_namespaceObject.z.object({
        ticker: external_zod_namespaceObject.z.string().min(1)
    })).query(async ({ ctx , input  })=>{
        const userId = ctx.session.user.id;
        const { ticker  } = input;
        const result = await (0,pg/* getHoldingsByTicker */.zS)(userId, ticker);
        if (typeof result === "number") {
            return result;
        } else {
            throw defaultError;
        }
    }),
    getHoldings: protectedProcedure.query(async ({ ctx  })=>{
        const userId = ctx.session.user.id;
        const dbResult = await (0,pg/* getHoldings */.LQ)(userId);
        const tickers = dbResult.map((row)=>row.ticker);
        const yhResult = await getMultipleTickersAsObjects(tickers);
        return dbResult.map((row)=>({
                ticker: row.ticker,
                company: yhResult[row.ticker]?.longName,
                currentPrice: yhResult[row.ticker]?.regularMarketPrice,
                purchasePrice: row.purchase_price,
                quantity: parseInt(row.quantity)
            }));
    }),
    getTimeSeriesValues: protectedProcedure.query(async ({ ctx  })=>{
        const userId = ctx.session.user.id;
        // Get new portfolio value
        const holdings = await (0,pg/* getHoldings */.LQ)(userId);
        const tickers = holdings.map((row)=>row.ticker);
        const yhResult = await getMultipleTickersAsObjects(tickers);
        const { cash  } = await (0,pg/* findUserById */.tj)(userId);
        let totalValue = cash;
        holdings.forEach((row)=>{
            totalValue += yhResult[row.ticker].regularMarketPrice * parseInt(row.quantity);
        });
        // Update portfolio
        await (0,pg/* updatePortfolio */.o9)(userId, totalValue);
        const dbResult = await (0,pg/* getPortfolio */.xp)(userId);
        return dbResult;
    })
});

;// CONCATENATED MODULE: ./src/server/trpc/router/screeener.ts






const screenerRouter = router({
    getScreenerResult: protectedProcedure.input(external_zod_namespaceObject.z.object({
        marketCap: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number().nullable(),
            max: external_zod_namespaceObject.z.number().nullable()
        }),
        avgVolume: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number().nullable(),
            max: external_zod_namespaceObject.z.number().nullable()
        }),
        PE: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number(),
            max: external_zod_namespaceObject.z.number()
        }),
        DE: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number(),
            max: external_zod_namespaceObject.z.number()
        }),
        beta: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number(),
            max: external_zod_namespaceObject.z.number()
        }),
        price: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number(),
            max: external_zod_namespaceObject.z.number()
        })
    })).query(async ({ input  })=>{
        // TODO: wire api call
        return await getQuoteList();
    }),
    viewScreeners: protectedProcedure.query(async ({ ctx  })=>{
        const userId = ctx.session.user.id;
        try {
            const result = await (0,pg/* viewScreeners */.AA)(userId);
            return result.map((screener)=>({
                    id: screener.screener_id,
                    name: screener.screener_name,
                    date: screener.create_time
                }));
        } catch (err) {
            if (err instanceof Error) {
                throw new server_.TRPCError({
                    code: "BAD_REQUEST",
                    message: err.message
                });
            } else {
                throw defaultError;
            }
        }
    }),
    getScreenerById: protectedProcedure.input(external_zod_namespaceObject.z.object({
        id: external_zod_namespaceObject.z.number().min(1)
    })).query(async ({ input  })=>{
        const { id  } = input;
        const result = await (0,pg/* getScreenerById */.h0)(id);
        const retVal = {
            marketCap: {
                min: result.market_cap_min,
                max: result.market_cap_max
            },
            avgVolume: {
                min: result.volume_min,
                max: result.volume_max
            },
            PE: {
                min: result.pe_min,
                max: result.pe_max
            },
            DE: {
                min: result.de_min,
                max: result.de_max
            },
            beta: {
                min: result.beta_min,
                max: result.beta_max
            },
            price: {
                min: result.price_min,
                max: result.price_max
            }
        };
        return retVal;
    }),
    saveScreener: protectedProcedure.input(external_zod_namespaceObject.z.object({
        name: external_zod_namespaceObject.z.string().min(1),
        marketCap: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number().nullable(),
            max: external_zod_namespaceObject.z.number().nullable()
        }),
        avgVolume: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number().nullable(),
            max: external_zod_namespaceObject.z.number().nullable()
        }),
        PE: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number(),
            max: external_zod_namespaceObject.z.number()
        }),
        DE: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number(),
            max: external_zod_namespaceObject.z.number()
        }),
        beta: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number(),
            max: external_zod_namespaceObject.z.number()
        }),
        price: external_zod_namespaceObject.z.object({
            min: external_zod_namespaceObject.z.number(),
            max: external_zod_namespaceObject.z.number()
        })
    })).mutation(async ({ ctx , input  })=>{
        const userId = ctx.session.user.id;
        const inputQuery = {
            userId,
            name: input.name,
            marketCapMax: input.marketCap.max,
            marketCapMin: input.marketCap.min,
            volumeMin: input.avgVolume.min,
            volumeMax: input.avgVolume.max,
            peMin: input.PE.min,
            peMax: input.PE.max,
            deMin: input.DE.min,
            deMax: input.DE.max,
            betaMin: input.beta.min,
            betaMax: input.beta.max,
            priceMin: input.price.min,
            priceMax: input.price.max
        };
        try {
            await (0,pg/* saveScreener */.ld)(inputQuery);
        } catch (err) {
            if (err instanceof Error) {
                throw new server_.TRPCError({
                    code: "BAD_REQUEST",
                    message: err.message
                });
            } else {
                throw defaultError;
            }
        }
    }),
    deleteScreener: protectedProcedure.input(external_zod_namespaceObject.z.object({
        id: external_zod_namespaceObject.z.number().min(1)
    })).mutation(async ({ input  })=>{
        const { id  } = input;
        try {
            await (0,pg/* deleteScreener */._J)(id);
        } catch (err) {
            if (err instanceof Error) {
                throw new server_.TRPCError({
                    code: "BAD_REQUEST",
                    message: err.message
                });
            }
            throw defaultError;
        }
    })
});

;// CONCATENATED MODULE: external "luxon"
const external_luxon_namespaceObject = require("luxon");
;// CONCATENATED MODULE: ./src/server/trpc/router/ticker.ts




const tickerRouter = router({
    getRecommendations: protectedProcedure.input(external_zod_namespaceObject.z.object({
        searchText: external_zod_namespaceObject.z.string().min(1)
    })).query(async ({ input  })=>{
        const { searchText  } = input;
        const searchTickers = searchText.split(",");
        for(let i = 0; i < searchTickers.length; i++){
            // Trim the excess whitespace.
            searchTickers[i] = searchTickers[i].replace(/^\s*/, "").replace(/\s*$/, "");
        }
        const result = await getRecommendations(searchTickers);
        return result;
    }),
    getTrending: publicProcedure.query(async ()=>{
        const quotes = await getTrending();
        if (!quotes) return [];
        const filteredQuotes = quotes.filter((quote)=>{
            if (quote.quoteType !== "EQUITY") return false;
            if (quote.fullExchangeName.includes("Nasdaq")) return true;
            if (quote.fullExchangeName.includes("NYSE")) return true;
            return false;
        });
        const result = filteredQuotes.map((quote)=>{
            return quote.symbol;
        });
        return result.slice(0, 10);
    }),
    search: protectedProcedure.input(external_zod_namespaceObject.z.object({
        searchText: external_zod_namespaceObject.z.string().min(1)
    })).query(async ({ input  })=>{
        const { searchText  } = input;
        const result = await search(searchText);
        return result;
    }),
    getTickerInfo: protectedProcedure.input(external_zod_namespaceObject.z.object({
        ticker: external_zod_namespaceObject.z.string().min(1)
    })).query(async ({ input  })=>{
        const { ticker  } = input;
        const queryResult = await getTickerInfo(ticker);
        return {
            volume: queryResult.summaryDetail?.volume,
            dayHigh: queryResult.summaryDetail?.dayHigh,
            dayLow: queryResult.summaryDetail?.dayHigh,
            bid: queryResult.summaryDetail?.bid,
            ask: queryResult.summaryDetail?.ask,
            fiftyTwoWeekLow: queryResult.summaryDetail?.fiftyTwoWeekLow,
            fiftyTwoWeekHigh: queryResult.summaryDetail?.fiftyTwoWeekHigh,
            name: queryResult.price?.longName,
            sector: queryResult.assetProfile?.sector,
            industry: queryResult.assetProfile?.industry,
            employees: queryResult.assetProfile?.fullTimeEmployees,
            summary: queryResult.assetProfile?.longBusinessSummary,
            marketState: queryResult.price?.marketState
        };
    }),
    getSPFiveHundred: protectedProcedure.input(external_zod_namespaceObject.z.object({
        startingPoint: external_zod_namespaceObject.z.date()
    })).query(async ({ input  })=>{
        const { startingPoint  } = input;
        const historicalResult = await getSPFiveHundred(startingPoint);
        const todayResult = await getTickerInfo("^GSPC");
        const historicalData = historicalResult.map((row)=>{
            const stringDate = row.date.toISOString().slice(0, -1);
            console.log(external_luxon_namespaceObject.DateTime.fromISO(stringDate, {
                zone: "America/New_York"
            }).toJSDate());
            return {
                time: external_luxon_namespaceObject.DateTime.fromISO(stringDate, {
                    zone: "America/New_York"
                }).toJSDate(),
                value: row.close
            };
        });
        historicalData.push({
            time: new Date(),
            value: todayResult.price?.regularMarketPrice
        });
        console.log(historicalData);
        return historicalData;
    })
});

;// CONCATENATED MODULE: ./src/server/trpc/router/transaction.ts





const transactionRouter = router({
    getHistory: protectedProcedure.query(async ({ ctx  })=>{
        const userId = ctx.session.user.id;
        const dbResult = await (0,pg/* getHistory */.s1)(userId);
        if (dbResult.length === 0) return [];
        const tickers = dbResult.map((row)=>row.ticker);
        const infoResult = await getMultipleTickersAsObjects(tickers);
        return dbResult.map((row, index)=>({
                index,
                ticker: row.ticker,
                company: infoResult[row.ticker]?.longName,
                price: row.stock_price,
                quantity: row.quantity,
                totalValue: row.total_value,
                transactionType: row.transaction_type
            }));
    }),
    makeTransaction: protectedProcedure.input(external_zod_namespaceObject.z.object({
        ticker: external_zod_namespaceObject.z.string().min(1),
        quantity: external_zod_namespaceObject.z.number().min(1),
        price: external_zod_namespaceObject.z.number().min(0),
        type: external_zod_namespaceObject.z.string()
    })).mutation(async ({ ctx , input  })=>{
        const userId = ctx.session.user.id;
        const { ticker , quantity , price , type  } = input;
        if (type !== "buy" && type !== "sell") {
            throw new server_.TRPCError({
                code: "BAD_REQUEST",
                message: "Invalid Transaction action. Please try again."
            });
        }
        if (type === "sell") {
            const currentQuantity = await (0,pg/* getHoldingsByTicker */.zS)(userId, ticker);
            if (currentQuantity < quantity) {
                throw new server_.TRPCError({
                    code: "BAD_REQUEST",
                    message: "You do not have enough tickers to sell. Please try again."
                });
            }
        }
        await (0,pg/* makeTransaction */.ym)(userId, ticker, type, price, quantity);
        return {
            message: "Success"
        };
    })
});

;// CONCATENATED MODULE: ./src/server/trpc/router/user.ts



const userRouter = router({
    getUserInfo: protectedProcedure.query(async ({ ctx  })=>{
        const { id  } = ctx.session.user;
        try {
            const result = await (0,pg/* findUserById */.tj)(id);
            return result;
        } catch (err) {
            throw new server_.TRPCError({
                code: "INTERNAL_SERVER_ERROR",
                message: err
            });
        }
    })
});

;// CONCATENATED MODULE: ./src/server/trpc/router/watchlist.ts






const watchlistRouter = router({
    addToWatchlist: protectedProcedure.input(external_zod_namespaceObject.z.object({
        ticker: external_zod_namespaceObject.z.string().min(1)
    })).mutation(async (req)=>{
        const { input: { ticker  } , ctx  } = req;
        const userId = ctx.session.user.id;
        try {
            await (0,pg/* addToWatchlist */.FW)(userId, ticker);
        } catch (err) {
            if (err instanceof Error) {
                throw new server_.TRPCError({
                    code: "BAD_REQUEST",
                    message: err.message
                });
            }
            throw new server_.TRPCError(defaultError);
        }
    }),
    deleteFromWatchlist: protectedProcedure.input(external_zod_namespaceObject.z.object({
        ticker: external_zod_namespaceObject.z.string().min(1)
    })).mutation(async (req)=>{
        const { input: { ticker  } , ctx  } = req;
        const userId = ctx.session.user.id;
        try {
            await (0,pg/* deleteFromWatchlist */.dF)(userId, ticker);
        } catch (err) {
            if (err instanceof Error) {
                throw new server_.TRPCError({
                    code: "BAD_REQUEST",
                    message: err.message
                });
            }
            throw new server_.TRPCError(defaultError);
        }
    }),
    getWatchlist: protectedProcedure.query(async ({ ctx  })=>{
        // Get from DB
        const userId = ctx.session.user.id;
        const dbResult = await (0,pg/* getWatchlist */.uT)(userId);
        if (dbResult.length === 0) return [];
        // Get Data
        const tickers = dbResult.map((row)=>row.ticker);
        const infoResult = await getMultipleTickers(tickers);
        // TODO: Check lastPrice, change, %change
        return infoResult.map((tickerInfo, index)=>({
                index,
                ticker: tickerInfo.symbol,
                company: tickerInfo.longName,
                lastPrice: tickerInfo.regularMarketPrice,
                change: tickerInfo.regularMarketChange,
                percentageChange: tickerInfo.regularMarketChangePercent,
                marketCap: tickerInfo.marketCap
            }));
    })
});

;// CONCATENATED MODULE: ./src/server/trpc/router/_app.ts








const appRouter = router({
    auth: authRouter,
    user: userRouter,
    ticker: tickerRouter,
    watchlist: watchlistRouter,
    screener: screenerRouter,
    transaction: transactionRouter,
    portfolio: portfolioRouter
});

;// CONCATENATED MODULE: ./src/pages/api/trpc/[trpc].ts




// export API handler
/* harmony default export */ const _trpc_ = ((0,next_namespaceObject.createNextApiHandler)({
    router: appRouter,
    createContext: createContext,
    onError: server_env.NODE_ENV === "development" ? ({ path , error  })=>{
        console.error(`❌ tRPC failed on ${path}: ${error}`);
    } : undefined
}));


/***/ }),

/***/ 2399:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ getServerAuthSession)
/* harmony export */ });
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _pages_api_auth_nextauth___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7720);


/**
 * Wrapper for unstable_getServerSession https://next-auth.js.org/configuration/nextjs
 * See example usage in trpc createContext or the restricted API route
 */ const getServerAuthSession = async (ctx)=>{
    return await (0,next_auth__WEBPACK_IMPORTED_MODULE_0__.unstable_getServerSession)(ctx.req, ctx.res, _pages_api_auth_nextauth___WEBPACK_IMPORTED_MODULE_1__.authOptions);
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [720], () => (__webpack_exec__(9374)));
module.exports = __webpack_exports__;

})();